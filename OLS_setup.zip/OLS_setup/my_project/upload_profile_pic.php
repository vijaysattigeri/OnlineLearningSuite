<?php
session_start();
include 'database_connect_parameters.inc';
if (isset($_SESSION['logged_in_user_name'])) {
    ?>
    <html>
        <head>
            <title>Profile picture upload </title>
            <script src="libraries/jquery-3.1.1.min.js"></script>
            <script src="libraries/smooth_scroll/jquery.easing.min.js"></script>
            <script src="libraries/smooth_scroll/scrolling-nav.js"></script>
            <link href="libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
            <link href="libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
            <script src="libraries/bootstrap/js/bootstrap.js"></script>
            <link href="smooth_scroll/scrolling-nav.css" rel="stylesheet" />
        </head>   

        <body style="padding-top:120px; background-image:url(OLS_Images/home_background.jpg); background-size:100%;background-attachment:fixed;">
            <!--Style By Vijay-->
            <div id="top_nav_bar_vj">
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="container-fluid" style="background-color:<?php
                    if ($_SESSION['logged_in_user_account_type'] == 2) {
                        echo "#4caf50";
                    } else {
                        echo "#c84747";
                    }
                    ?>;font-variant-caps:all-petite-caps;">
                        <!--This gives enough padding for navbar elements-->
                        <div class="navbar-header" style="color:#ffffff;">
                            <button type="button" class="navbar-toggle" data-target="#resize_menu_vj_top" data-toggle="collapse">
                                <!-- To get THREE bars(Icon bars) when we resize the window to smaller size-->
                                <span class="glyphicon glyphicon-menu-hamburger"></span>
                                <span>Menu</span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse" id="resize_menu_vj_top">
                            <ul class="nav navbar-nav">
                                <li id="list_id_index"><a class="page-scroll" href="index.php"><img src="OLS_Images/home.jpg" width="50" height="50" style="border-radius:2px 18px" /><span style="color:#ffffff; font:initial; font-style:italic; font-size:xx-large;">&nbsp; Online Learning Suite</span></a></li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">                            
                                <li id="list_id_profile"><a href="user_profile.php?user_name=<?php echo $_SESSION['logged_in_user_name']; ?>"><img src="profile_pics/<?php echo $_SESSION['logged_in_user_profile_pic_name']; ?>" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; PROFILE</span></a></li>
                                <li id="list_id_logout"><a href="logout.php"><img src="OLS_Images/logout.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; LOGOUT</span></a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>


            <div class="container" style="padding:50px 50px 50px 50px;background-color:white;border-radius:20px 20px; box-shadow:0 1px 20px <?php
            if ($_SESSION['logged_in_user_account_type'] == 2) {
                echo "rgb(76, 175, 80)";
            } else {
                echo "rgb(200, 71, 71)";
            }
            ?>;">         
                <form action="upload_profile_pic_script.php" method="post" enctype="multipart/form-data">                    
                    <div class="row">
                        <div class="col-md-4">
                            <h4>Select profile picture</h4>
                        </div>
                        <div class="col-md-4">
                            <input type="file" name="image_file" accept="image/*" class="form-control" /> 
                        </div>
                        <div class="col-md-4">
                            <input type="submit" value="UPLOAD" name="profile_pic_upload" class="btn btn-success"/>
                        </div>                         
                    </div> 
                </form>   
            </div>
        </body>
    </html>

    <?php
} else {
    header("location:login.php");
}
?>