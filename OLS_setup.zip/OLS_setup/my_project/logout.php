<html>
    <head>
        <title>Logging-out OLS</title>
    </head>
    <body>
        <?php
        session_start();
        if (isset($_SESSION['logged_in_user_name']) || isset($_SESSION['verification_required_user']) || isset($_SESSION['logged_in_maintain_user'])) {
            if (session_destroy()) {
                echo "<h1>You're successfully logged-out.</h1>";
                ?>
                <script type="text/javascript">
                    function redirect_to_login() {
                        window.location = "login.php";
                    }
                    setTimeout(redirect_to_login, 100);
                </script>
                <?php
            } else {
                echo "<h1 style='color:red'>Error : Logging-out FAILED.</h1>";
            }
        } else {
            header("location:login.php");
        }
        ?>
    </body>
</html>