<?php
session_start();
include 'database_connect_parameters.inc';

if (isset($_SESSION['logged_in_user_name'])) {
    header("location:index.php");
}
if (isset($_SESSION['verification_required_user'])) {
    $verification_message = "";
    $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
    if (!$con) {
        die('Could not connect to database : ' . mysql_error());
    }
    $sess_uname = $_SESSION['verification_required_user'];
    $qry1 = "select * from user_accounts where user_name='$sess_uname';";
    $res1 = mysqli_query($con, $qry1);
    $row = mysqli_fetch_array($res1);
    if (isset($_REQUEST['verification_submit'])) {
        $read_verification_code = $_REQUEST['read_verification_code'];
        if ($read_verification_code == $row['verification_code']) {
            $user_id = $row['user_id'];
            $qry2 = "UPDATE `user_accounts` SET `verified` = '1' WHERE user_id = '$user_id' and user_name='$sess_uname';";
            $res2 = mysqli_query($con, $qry2);
            if ($res2) {

                //set the user name and details in the session
                $_SESSION['logged_in_user_name'] = $row['user_name'];
                $_SESSION['logged_in_user_id'] = $row['user_id'];
                $_SESSION['logged_in_user_stream'] = $row['stream'];
                $_SESSION['logged_in_user_account_type'] = $row['account_type'];
                $_SESSION['logged_in_user_profile_pic_name'] = $row['profile_pic_name'];

                unset($_SESSION['verification_required_user']); //Remove the associated session variable for the user just verified.
                header("location:index.php");
            } else {
                echo "<h1 style='color:red'>Database ERROR while updating verification flag. Details :" . mysqli_error($con) . " </h1>";
                exit(1);
            }
        } else {
            $verification_message = "<h1 style='color:red'>Incorrect verification code please enter the code again.</h1>";
        }
    }
    // Don't put the following code in "else" block. beacuse it sholud run in all case with error message ($verification_messgae) set above
    ?>
    <html>
        <head>
            <title>Verification page</title>
            <script src="libraries/jquery-3.1.1.min.js"></script>    
            <link href="libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
            <link href="libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
            <script src="libraries/bootstrap/js/bootstrap.js"></script>
        </head>
        <body style="padding-top:80px; background-image:url(OLS_Images/login_registration.jpg); background-size:100%;background-attachment:fixed;"> 

            <div class="container" style="padding:25px 25px 25px 25px; background-color:white;border-radius:20px 20px; box-shadow:0 1px 100px rgb(200, 71, 71);">

                <?php
                if (isset($verification_message)) {
                    echo $verification_message;
                }
                ?>

                <form action="" method="post">
                    <div style="text-align: center">
                        <label>
                            <p style="font:30px sans-serif;">Welcome <b><i> <?php echo $sess_uname; ?> </i></b>. Enter the verification code sent to EmailID : <b><i><?php echo $row['email']; ?></i></b></p>
                            <div class="row">
                                <div class="col-md-4">
                                </div>
                                <div class="col-md-4">
                                    <input type="text" size="7" max="4" name="read_verification_code" class="form-control" />       
                                </div>
                                <div class="col-md-4">
                                </div>
                            </div>
                        </label>
                        <br/>
                        <br/>
                        <input type="submit" name="verification_submit" value="VERIFY" class="btn btn-success" />
                        <a href="logout.php" class="btn btn-danger">LOGOUT</a>
                    </div>
                </form>

            </div>
        </body>
    </html>
    <?php
} else {
    header("location:login.php");
}
?>