<?php
session_start();
include 'database_connect_parameters.inc';
if (isset($_SESSION['logged_in_maintain_user'])) {
    ?>
    <html>

        <head>

            <title>Maintenance team</title>
            <!-- First INCLUDE JQuery library later include/link bootstrap-->
            <script src="libraries/jquery-3.1.1.min.js"></script>
            <script src="libraries/smooth_scroll/jquery.easing.min.js"></script>
            <script src="libraries/smooth_scroll/scrolling-nav.js"></script>
            <link href="libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
            <link href="libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
            <script src="libraries/bootstrap/js/bootstrap.js"></script>
            <link href="smooth_scroll/scrolling-nav.css" rel="stylesheet" />
        </head>

        <body style="padding-top:80px; background-image:url(OLS_Images/maintain_bg.jpg); background-size:100%;background-attachment:fixed;">
            <!--Style By Vijay-->

            <div id="top_nav_bar_vj">
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="container-fluid" style="background-color:#0080ff;font-variant-caps:all-petite-caps;">
                        <!--This gives enough padding for navbar elements-->
                        <div class="navbar-header" style="color:#ffffff;">
                            <button type="button" class="navbar-toggle" data-target="#resize_menu_vj_top" data-toggle="collapse">
                                <!-- To get THREE bars(Icon bars) when we resize the window to smaller size-->
                                <span class="glyphicon glyphicon-menu-hamburger"></span>
                                <span>Menu</span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse" id="resize_menu_vj_top">
                            <ul class="nav navbar-nav">
                                <li id="list_id_index"><a class="page-scroll" href="#"><img src="OLS_Images/settings.jpg" width="50" height="50" style="border-radius:2px 18px" /><span style="color:#ffffff; font:initial; font-style:italic; font-size:xx-large;">&nbsp; OLS Maintenance home</span></a></li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">                                
                                <li id="list_id_logout"><a href="logout.php"><img src="OLS_Images/logout.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; LOGOUT</span></a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>

            <div class="container-fluid">  

                <div class="row" style="padding:100px 100px 100px 100px;">      

                    <div class="col-md-5" style="background-color:white;border-radius:20px 20px; box-shadow:0 1px 100px rgb(200, 71, 71);">
                        <div id="exam_image" style="text-align:center;">
                            <h2><a href="tutorial_section/maintain_tutorial.php">Monitor Tutorial Section</a></h2>
                            <a href="tutorial_section/maintain_tutorial.php"> <img src="OLS_Images/tutorial_section.jpg" width="420" height="420" alt="Block User Image" style="padding:40px 40px 40px 40px; border-radius:20px 20px;" /></a>
                        </div>
                        <br/>
                        <p style="padding:10px 10px 10px 10px; font:25px xx-large;text-align:justify;word-spacing:2px;">
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; This interface provides deletion of in-appropriate tutorials posted by resource persons.                           
                        </p>
                    </div>

                    <div class="col-md-2">

                    </div>

                    <div class="col-md-5" style="background-color:white;border-radius:20px 20px; box-shadow:0 1px 100px rgb(200, 71, 71);">
                        <div id="exam_image" style="text-align:center;">
                            <h2><a href="resource_house/resource_admin.php">Monitor Resource house</a></h2>
                            <a href="resource_house/resource_admin.php"> <img src="OLS_Images/resource_house.jpg" width="420" height="420" alt="Block User Image" style="padding:40px 40px 40px 40px; border-radius:20px 20px;" /></a>
                        </div>
                        <br/>
                        <p style="padding:10px 10px 10px 10px; font:25px xx-large;text-align:justify;word-spacing:2px;">
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; This interface facilitates validating of fresh uploaded files by all users.                           
                        </p>
                    </div>

                </div> 

                <div class="row" style="padding:100px 100px 100px 100px;">      

                    <div class="col-md-5" style="background-color:white;border-radius:20px 20px; box-shadow:0 1px 100px rgb(200, 71, 71);">
                        <div id="exam_image" style="text-align:center;">
                            <h2><a href="self_assessment/maintain_exam.php">Monitor Self-assessment Exam</a></h2>
                            <a href="self_assessment/maintain_exam.php"> <img src="OLS_Images/self_assessment.jpg" width="420" height="420" alt="Block User Image" style="padding:40px 40px 40px 40px; border-radius:20px 20px;" /></a>
                        </div>
                        <br/>
                        <p style="padding:10px 10px 10px 10px; font:25px xx-large;text-align:justify;word-spacing:2px;">
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; This interface provides question addition and removal from OLS self-assessment section.                         
                        </p>
                    </div>

                    <div class="col-md-2">

                    </div>

                    <div class="col-md-5" style="background-color:white;border-radius:20px 20px; box-shadow:0 1px 100px rgb(200, 71, 71);">
                        <div id="exam_image" style="text-align:center;">
                            <h2><a href="discussion_forum/maintain_discuss.php">Monitor Discussion forum</a></h2>
                            <a href="discussion_forum/maintain_discuss.php"> <img src="OLS_Images/discussion_forum.jpg" width="420" height="420" alt="Block User Image" style="padding:40px 40px 40px 40px; border-radius:20px 20px;" /></a>
                        </div>
                        <br/>
                        <p style="padding:10px 10px 10px 10px; font:25px xx-large;text-align:justify;word-spacing:2px;">
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; This interface facilitates deleting of in-appropriate questions and answers from the discussion forum.                            
                        </p>
                    </div>

                </div> 

                <div class="row" style="padding:100px 100px 100px 100px;">      

                    <div class="col-md-5" style="background-color:white;border-radius:20px 20px; box-shadow:0 1px 100px rgb(200, 71, 71);">
                        <div id="exam_image" style="text-align:center;">
                            <h2><a href="block_user.php">Block User Accounts</a></h2>
                            <a href="block_user.php"> <img src="OLS_Images/block_user.jpg" width="420" height="420" alt="Block User Image" style="padding:40px 40px 40px 40px; border-radius:20px 20px;" /></a>
                        </div>
                        <br/>
                        <p style="padding:10px 10px 10px 10px; font:25px xx-large;text-align:justify;word-spacing:2px;">
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Block misbehaving users here for temporary period of time. This won't delete user's database. An email message is sent to user's email ID as soon he is blocked.                           
                        </p>
                    </div>

                    <div class="col-md-2">

                    </div>

                    <div class="col-md-5" style="background-color:white;border-radius:20px 20px; box-shadow:0 1px 100px rgb(200, 71, 71);">
                        <div id="exam_image" style="text-align:center;">
                            <h2><a href="unblock_user.php">Un-block User Accounts</a></h2>
                            <a href="unblock_user.php"> <img src="OLS_Images/unblock.jpg" width="420" height="420" alt="Block User Image" style="padding:40px 40px 40px 40px; border-radius:20px 20px;" /></a>
                        </div>
                        <br/>
                        <p style="padding:10px 10px 10px 10px; font:25px xx-large;text-align:justify;word-spacing:2px;">
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;This section un-blocks the previously blocked user. An email message is sent to user's email ID as soon as he is unblocked.                           
                        </p>
                    </div>

                </div> 

                <div class="row" style="padding:100px 100px 100px 100px;">      

                    <div class="col-md-5" style="background-color:white;border-radius:20px 20px; box-shadow:0 1px 100px rgb(200, 71, 71);">
                        <div id="exam_image" style="text-align:center;">
                            <h2><a href="activate_resource_person.php">Activate resource person accounts</a></h2>
                            <a href="activate_resource_person.php"> <img src="OLS_Images/resource_persons.jpg" width="420" height="420" alt="Block User Image" style="padding:40px 40px 40px 40px; border-radius:20px 20px;" /></a>
                        </div>
                        <br/>
                        <p style="padding:10px 10px 10px 10px; font:25px xx-large;text-align:justify;word-spacing:2px;">
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Resource persons (Lecturers,professors,teachers) are explicitly activated through this interface unlike normal users(learners) where email verification is enough.                           
                        </p>
                    </div>

                    <div class="col-md-2">

                    </div>
                </div> 

            </div>
        </body>
    </html>
    <?php
} else {
    header("location:login.php");
}
?>