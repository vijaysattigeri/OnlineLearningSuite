<?php
session_start();
include '../database_connect_parameters.inc';
if (isset($_SESSION['logged_in_user_name'])) {
    ?>
    <html>
        <head>
            <title>Tutorial deletion</title>
            <script type='text/javascript'>
                function time_load() {
                    setTimeout(redirect, 5000);
                }
                function redirect() {
                    window.location.href = 'index.php';
                }</script>
        </head>
        <body onload="time_load()">
            <?php
            if (isset($_REQUEST['tutorial_id']) && isset($_REQUEST['submit_invalid'])) {

                $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
                if (!$con) {
                    die('Could not connect to database: ' . mysql_error());
                }

                $detach_file = 1;
                $detach_row = 1;
                //Delete attachments from "attachments" folder
                foreach ($_REQUEST['tutorial_id'] as $id) {
                    $qry1 = "select * from tutorial_attachments where tutorial_id_foreign='$id'";
                    $res1 = mysqli_query($con, $qry1);
                    while ($row = mysqli_fetch_array($res1)) {
                        // //If file name is null then string will be like "attachments/" which tries to delete directory which is NON-EMPTY. We cannot delele non-empty directory
                        if ($row['stored_file_name'] != "") {
                            if (unlink("attachments/" . $row['stored_file_name'])) {
                                
                            } else {
                                $detach_file = 0;
                            }
                        }
                    }
                }
                //Delete row entry from tutorial_attachments table  
                foreach ($_REQUEST['tutorial_id'] as $id) {
                    $qry2 = "DELETE FROM `tutorial_attachments` WHERE `tutorial_attachments`.`tutorial_id_foreign` = '$id'";
                    $res2 = mysqli_query($con, $qry2);
                    if ($res2 == TRUE) {
                        
                    } else {
                        $detach_row = 0;
                    }
                }

                $delete_tutorial_file = 1;
                $delete_tutorial_row = 1;
                //Delete files from "videos and images" folder
                foreach ($_REQUEST['tutorial_id'] as $id) {
                    $qry3 = "select * from tutorial_section where tutorial_id='$id'";
                    $res3 = mysqli_query($con, $qry3);
                    while ($row = mysqli_fetch_array($res3)) {
                        //If file name is null then string will be like "videos/" and "images/" which tries to delete directory(videos,images) which will be NON-EMPTY. We cannot delele non-empty directories
                        if ($row['video_path'] != "") {
                            if (unlink("videos/" . $row['video_path'])) {
                                
                            } else {
                                $delete_tutorial_file = 0;
                            }
                        }
                        if ($row['image_path'] != "") {
                            if (unlink("images/" . $row['image_path'])) {
                                
                            } else {
                                $delete_tutorial_file = 0;
                            }
                        }
                    }
                }
                //Delete row entry from tutorial_section table  
                foreach ($_REQUEST['tutorial_id'] as $id) {
                    $qry4 = "DELETE FROM `tutorial_section` WHERE `tutorial_section`.`tutorial_id` = '$id'";
                    $res4 = mysqli_query($con, $qry4);
                    if ($res4 == TRUE) {
                        
                    } else {
                        $delete_tutorial_row = 0;
                    }
                }

                $rep1 = "";
                $rep2 = "";
                if ($detach_file == 1 && $detach_row == 1) {
                    $rep1 = "<h3 style='color:green'>Attachments deleted successfully...</h3>";
                } else {
                    $rep1 = "<h3 style='color:red'>Attachments deletion failed...</h3>";
                }
                if ($delete_tutorial_file == 1 && $delete_tutorial_row == 1) {
                    $rep2 = "<h3 style='color:green'>Tutorial files deleted successfully...</h3>";
                } else {
                    $rep2 = "<h3 style='color:red'>Tutorial deletion failed...</h3>";
                }

                $report = "<center><h1>-: REPORT :-</h1><table border=border cellspacing='0' cellpadding='10'>";
                $report .= "<tr><td>$rep1</td></tr>";
                $report .= "<tr><td>$rep2</td></tr>";
                $report .= "</table><h2 style='color:red'>In 5 seconds the page will be redirected</h2></center><a href='index.php'>Tutorial Home</body></html>";
                echo "<br/>$report</br>";
                mysqli_close($con);
            } else {
                // redirect to the maintain_resource.php
                header("location:index.php");
            }
            ?>
            <?php
        } else {
            header("location:../login.php");
        }
        ?>