<?php
session_start();
include '../database_connect_parameters.inc';
if (isset($_SESSION['logged_in_user_name'])) {
    if ($_SESSION['logged_in_user_account_type'] == 2) {
        ?>
        <html>     

            <head>
                <title>Tutorial post</title>
                <script src="../libraries/jquery-3.1.1.min.js"></script>
                <script src="../libraries/smooth_scroll/jquery.easing.min.js"></script>
                <script src="../libraries/smooth_scroll/scrolling-nav.js"></script>
                <link href="../libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
                <link href="../libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
                <script src="../libraries/bootstrap/js/bootstrap.js"></script>
                <link href="../smooth_scroll/scrolling-nav.css" rel="stylesheet" />
                <script type="text/javascript">
                    function validate() {
                        var titl = document.getElementById('tut_title').value;
                        var ex = document.getElementById('expln').value;
                        if (titl == "" || ex == "") {
                            alert("Title and explanation should not be empty !");
                            return false;
                        } else
                            return true;
                    }
                </script>
            </head>   

            <body style="padding-top:100px; padding-bottom: 100px; background-image:url(../OLS_Images/tutorial_section.jpg); background-size:100%;background-attachment:fixed;"> 

                <div id="top_nav_bar_vj">
                    <nav class="navbar navbar-default navbar-fixed-top">
                        <div class="container-fluid" style="background-color:<?php
                        if ($_SESSION['logged_in_user_account_type'] == 2) {
                            echo "#4caf50";
                        } else {
                            echo "#c84747";
                        }
                        ?>;font-variant-caps:all-petite-caps;">
                            <!--This gives enough padding for navbar elements-->
                            <div class="navbar-header" style="color:#ffffff;">
                                <button type="button" class="navbar-toggle" data-target="#resize_menu_vj_top" data-toggle="collapse">
                                    <!-- To get THREE bars(Icon bars) when we resize the window to smaller size-->
                                    <span class="glyphicon glyphicon-menu-hamburger"></span>
                                    <span>Menu</span>
                                </button>
                            </div>
                            <div class="navbar-collapse collapse" id="resize_menu_vj_top">
                                <ul class="nav navbar-nav">
                                    <li id="list_id_index"><a href="../index.php"><img src="../OLS_Images/home.jpg" width="50" height="50" style="border-radius:2px 18px" /><span style="color:#ffffff; font:initial; font-style:italic; font-size:xx-large;">&nbsp; Online Learning Suite</span></a></li>
                                </ul>
                                <ul class="nav navbar-nav navbar-right">                              
                                    <li id="list_id_profile"><a href="../user_profile.php?user_name=<?php echo $_SESSION['logged_in_user_name']; ?>" target="_blank"><img src="../profile_pics/<?php echo $_SESSION['logged_in_user_profile_pic_name']; ?>" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; PROFILE</span></a></li>
                                    <?php
                                    // Posting link should be only for RESOURCE persons.
                                    if ($_SESSION['logged_in_user_account_type'] == 2) {
                                        ?>
                                        <li id="list_id_delete_a_tutorial"><a href="self_tutorial_delete_ui.php"><img src="../OLS_Images/delete.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; DELETE YOUR TUTORIAL </span></a></li>
                                    <?php }
                                    ?>
                                    <li id="list_id_logout"><a href="../logout.php"><img src="../OLS_Images/logout.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; LOGOUT</span></a></li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                </div>

                <div class="container">
                    <form action="post_tutorial_script.php" method="post" enctype="multipart/form-data" onsubmit="return validate();" style="padding:19px 29px 29px;margin: 0 auto;background-color:#f2f2f2; border: 1px solid #080808; border-radius: 5px;box-shadow: 0 1px 70px rgb(0, 0, 0);font-family: Tahoma, Geneva, sans-serif;font-weight: lighter;">
                        <h2 style="color:#4caf50;">Input Tutorial</h2>
                        <hr>
                        <div class="row">
                            <div class="col-md-4">
                                <h4>Enter the title of tutorial(within 90 characters)</h4>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" id="tut_title" name="tutorial_title" maxlength="95" size="95" placeholder="Name of the tutorial" required="required" class="form-control" />
                                </div>
                            </div>
                        </div>

                        <div class="row">                        
                            <div class="col-md-4">
                                <h4>Insert video OR audio</h4>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="file" name="video_file" class="form-control" accept="./*" />                                   
                                </div>
                            </div>
                        </div>

                        <div class="row">                        
                            <div class="col-md-4">
                                <h4>Insert Image</h4>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="file" name="image_file" accept="image/*" class="form-control" />                                   
                                </div>
                            </div>
                        </div>

                        <div class="row">                        
                            <div class="col-md-4">
                                <h4>Attach related files here(Max. 10 files)</h4>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="file" name="attached_files[]" accept="./*" multiple="true" class="form-control" />
                                </div>
                            </div>
                        </div>

                        <div class="row">                        
                            <div class="col-md-4">
                                <h4>Enter explanation of the tutorial</h4>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">                                   
                                    <textarea id="expln" name="explanation" rows="16" placeholder="Explain tutorial" required="required" class="form-control" style="padding:20px 20px 20px 20px;"></textarea>
                                </div>
                            </div>
                        </div>   

                        <div class="form-group">                  
                            <button type="submit" class="btn btn-success" name="form_submit" >
                                <span class="glyphicon glyphicon-send"></span> &nbsp; POST TUTORIAL
                            </button> 
                            <input class="btn btn-warning" style="float:right;" value="RESET" type="reset">
                        </div>

                    </form>           
                </div>
            </body>
        </html>
        <?php
    } else {
        header("location:index.php");
    }
} else {
    header("location:../login.php");
}
?>
