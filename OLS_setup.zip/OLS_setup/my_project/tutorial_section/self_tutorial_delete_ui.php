<?php
session_start();
include '../database_connect_parameters.inc';
if (isset($_SESSION['logged_in_user_name'])) {
    ?>
    <html>
        <head>
            <title>Self tutorial delete</title>  
            <script src="../libraries/jquery-3.1.1.min.js"></script>
            <script src="../libraries/smooth_scroll/jquery.easing.min.js"></script>
            <script src="../libraries/smooth_scroll/scrolling-nav.js"></script>
            <link href="../libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
            <link href="../libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
            <script src="../libraries/bootstrap/js/bootstrap.js"></script>
            <link href="../smooth_scroll/scrolling-nav.css" rel="stylesheet" />
            <script type="text/javascript">
                function check()
                {
                    if (confirm("Are you sure want to submit ?"))
                    {
                        return true;
                    } else
                    {
                        return false;
                    }
                }
            </script>
        </head>
        <body style="padding-top:100px; padding-bottom: 100px; background-image:url(../OLS_Images/tutorial_section.jpg); background-size:100%;background-attachment:fixed;"> 

            <div id="top_nav_bar_vj">
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="container-fluid" style="background-color:<?php
                    if ($_SESSION['logged_in_user_account_type'] == 2) {
                        echo "#4caf50";
                    } else {
                        echo "#c84747";
                    }
                    ?>;font-variant-caps:all-petite-caps;">
                        <!--This gives enough padding for navbar elements-->
                        <div class="navbar-header" style="color:#ffffff;">
                            <button type="button" class="navbar-toggle" data-target="#resize_menu_vj_top" data-toggle="collapse">
                                <!-- To get THREE bars(Icon bars) when we resize the window to smaller size-->
                                <span class="glyphicon glyphicon-menu-hamburger"></span>
                                <span>Menu</span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse" id="resize_menu_vj_top">
                            <ul class="nav navbar-nav">
                                <li id="list_id_index"><a href="../index.php"><img src="../OLS_Images/home.jpg" width="50" height="50" style="border-radius:2px 18px" /><span style="color:#ffffff; font:initial; font-style:italic; font-size:xx-large;">&nbsp; Online Learning Suite</span></a></li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">                              
                                <li id="list_id_profile"><a href="../user_profile.php?user_name=<?php echo $_SESSION['logged_in_user_name']; ?>" target="_blank"><img src="../profile_pics/<?php echo $_SESSION['logged_in_user_profile_pic_name']; ?>" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; PROFILE</span></a></li>
                                <?php
                                // Posting link should be only for RESOURCE persons.
                                if ($_SESSION['logged_in_user_account_type'] == 2) {
                                    ?>
                                    <li id="list_id_post_a_tutorial"><a href="post_tutorial_ui.php"><img src="../OLS_Images/post_tutorial.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; POST A TUTORIAL </span></a></li>
                                <?php }
                                ?>
                                <li id="list_id_logout"><a href="../logout.php"><img src="../OLS_Images/logout.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; LOGOUT</span></a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>

            <div class="container">
                <form action="self_tutorial_delete_action_script.php" method="post" onsubmit="return check();" style="padding:19px 29px 29px;margin: 0 auto;background-color:#f2f2f2; border: 1px solid #080808; border-radius: 5px;box-shadow: 0 1px 70px rgb(0, 0, 0);font-family: Tahoma, Geneva, sans-serif;font-weight: lighter;">
                    <?php
                    $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
                    if (!$con) {
                        die('Could not connect to databse: ' . mysql_error());
                    }
                    $found = FALSE;
                    $user_name = $_SESSION['logged_in_user_name']; // Get current user from session
                    $qry = "select * from tutorial_section where user_name='$user_name' order by posted_date desc";
                    $result = mysqli_query($con, $qry);
                    $out_res = "<table class='table table-striped'><tr><th>Tutorial Title</th><th>Resource person</th><th>Posted date</th><th>Stream</th><th>Check to delete</th></tr>";
                    while ($row = mysqli_fetch_array($result)) {
                        $found = TRUE;
                        $stream = "";
                        switch ($row['stream']) {
                            case 1: $stream = "Computer Science";
                                break;
                            case 2: $stream = "Information Science";
                                break;
                            case 3: $stream = "Civil Engineering";
                                break;
                            case 4: $stream = "Mechanical Engineering";
                                break;
                            case 5: $stream = "Electronics Engineering";
                                break;
                            case 6: $stream = "Other";
                                break;
                            default : $stream = "";
                                break;
                        }
                        $out_res .= "<tr><td>" . htmlentities($row['tutorial_title'], ENT_QUOTES) . "</td><td>" . htmlentities($row['user_name'], ENT_QUOTES) . "</td><td>" . htmlentities($row['posted_date'], ENT_QUOTES) . "</td><td>$stream</td><td><label><input type='checkbox' name='tutorial_id[]' value='" . htmlentities($row['tutorial_id'], ENT_QUOTES) . "'/>&nbsp; Delete</label></td></tr>";
                    }
                    mysqli_close($con);
                    if ($found == FALSE) {
                        $out_res = "<h2 style='color:red'>You have not uploaded any tutorial.</h2>";
                    } else {
                        $out_res .= "</table><br/><br/>";
                    }
                    echo "<br/>$out_res<br/>";
                    ?> 
                    <input type='submit' name='submit_invalid' value='SUBMIT' class="btn btn-danger" />
                    <input type='reset' value='RESET' class="btn btn-warning" style="float: right;" />
                </form>
            </div>
        </body>
    </html>
    <?php
} else {
    header("location:../login.php");
}
?>