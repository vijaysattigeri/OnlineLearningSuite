<?php
session_start();
include '../database_connect_parameters.inc';
if (isset($_SESSION['logged_in_user_name'])) {
    ?>
    <html>
        <head>
            <title>Posting tutorial</title>
        </head>
        <body>
            <?php
            if (isset($_REQUEST['form_submit'])) {

                $vid_name_stored = "." . pathinfo($_FILES['video_file']['name'], PATHINFO_EXTENSION); //get file extention
                $vid_size = $_FILES['video_file']['size'];
                $vid_type = $_FILES['video_file']['type'];
                $vid_error = $_FILES['video_file']['error'];

                $img_name_stored = "." . pathinfo($_FILES['image_file']['name'], PATHINFO_EXTENSION);
                $img_size = $_FILES['image_file']['size'];
                $img_type = $_FILES['image_file']['type'];
                $img_error = $_FILES['image_file']['error'];


                $attchments_name = $_FILES['attached_files']['name'];
                $attchments_size = $_FILES['attached_files']['size'];
                $attchments_temp = $_FILES['attached_files']['tmp_name'];
                $attchments_error = $_FILES['attached_files']['error'];

                //Error checking
                $error_flag = 0; // exit() is used although for extra reliability towsrds $error_flag is being used.
                $max_upload_file_size = 50 * 1024 * 1024;
                //if((false1111) && (false||true||false||true)) put the correct number of parenthesis "false1111" matters.
                if (($_FILES['video_file']['name'] != "") && (($vid_size > $max_upload_file_size) || ((strcasecmp(strtok($vid_type, '/'), "audio") != 0) && (strcasecmp(strtok($vid_type, '/'), "video") != 0)) || ($vid_error != 0))) {
                    echo"<html><head><title>Video error</title><script type='text/javascript'>function time_load(){  setTimeout(redirect, 5000);} function redirect() { window.location.href = 'post_tutorial_ui.php'; } </script></head><body onload='time_load()'><h1 style='color:red'> $vid_type You're exceeding maximum size limit OR You're uploading Illegal file. Maximum size limit of one file is 50MB. And only videos/audios are allowed. <br/>Redirecting wait...</h1></body></html>";
                    $error_flag = 1;
                    exit(1);
                }
                if (($_FILES['image_file']['name'] != "") && (($img_size > $max_upload_file_size || $img_size == 0) || (strcasecmp(strtok($img_type, '/'), "image") != 0) || ($img_error != 0))) {
                    echo"<html><head><title>Image error</title><script type='text/javascript'>function time_load(){  setTimeout(redirect, 5000);} function redirect() { window.location.href = 'post_tutorial_ui.php'; } </script></head><body onload='time_load()'><h1 style='color:red'>You're exceeding maximum size limit OR You're uploading illegal file. Maximum size limit of one file is 50MB. And only images are allowed. <br/>Redirecting wait...</h1></body></html>";
                    $error_flag = 1;
                    exit(2);
                }
                if ($attchments_name[0] != "") {
                    $j = 0;
                    foreach ($attchments_name as $at_name) {
                        if ($attchments_size[$j] > $max_upload_file_size || $attchments_error[$j] != 0) {
                            echo"<html><head><title>Attachment files  error</title><script type='text/javascript'>function time_load(){  setTimeout(redirect, 5000);} function redirect() { window.location.href = 'post_tutorial_ui.php'; } </script></head><body onload='time_load()'><h1 style='color:red'>Error occured in ATTACHED files. Please check the size. Maximum allowed size is 50MB <br/>Redirecting wait...</h1></body></html>";
                            $error_flag = 1;
                            exit(3);
                        }
                        $j++;
                    }
                }

                //Database connection and insertion of data
                if ($error_flag == 0) {     // only if NO ERROR found
                    $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
                    if (!$con) {
                        die('Could not connect to database: ' . mysql_error());
                        exit(14);
                    }

                    $qry1 = "SELECT tutorial_id from tutorial_section order by tutorial_id desc";
                    $tutorial_id = 1;
                    $res1 = mysqli_query($con, $qry1);
                    $num_arr = mysqli_fetch_all($res1, MYSQLI_NUM);
                    $tot_rows = count($num_arr);
                    if ($tot_rows > 0) {
                        $tutorial_id = $num_arr[0][0];
                        $tutorial_id++;
                    }
                    $vid_name_stored = "video_$tutorial_id" . $vid_name_stored; // To guarantee unique name for all files
                    $img_name_stored = "image_$tutorial_id" . $img_name_stored;

                    if ($_FILES['video_file']['name'] == "") {
                        $vid_name_stored = "";
                    }
                    if ($_FILES['image_file']['name'] == "") {
                        $img_name_stored = "";
                    }


                    //To mark the row(tutorial) to which attachments to be added. if we use the AUTO-INCREMENTED 'tutorial_id' value we may get foreign key error when we've deleted some of rows.
                    $q_tut_id = "SELECT tut_attach_id from tutorial_section order by tut_attach_id desc";
                    $tut_attach_id = 1;
                    $res_tut_id = mysqli_query($con, $q_tut_id);
                    $num_arr_tut_id = mysqli_fetch_all($res_tut_id, MYSQLI_NUM);
                    $tot_rows_tut_id = count($num_arr_tut_id);
                    if ($tot_rows_tut_id > 0) {
                        $tut_attach_id = $num_arr_tut_id[0][0];
                        $tut_attach_id++;
                    }

                    $user_name = $_SESSION['logged_in_user_name'];
                    $tutorial_title = mysqli_real_escape_string($con, $_REQUEST['tutorial_title']);
                    $explanation = mysqli_real_escape_string($con, $_REQUEST['explanation']);
                    $stream = $_SESSION['logged_in_user_stream'];
                    if ($stream == 0) {
                        $stream = 1;
                    }
                    date_default_timezone_set("Asia/Kolkata"); //Refer PHP documentation manual. Navigate to "PHP Manual-> List of Supported Timezones->Asia
                    $dt = date('Y-m-d H:i:s');

                    $qry2 = "INSERT INTO `tutorial_section` (`tutorial_title`, `user_name`, `posted_date`, `video_path`,`type`, `image_path`, `explanation`, `stream`,`number_of_attachments`,`tut_attach_id`) VALUES ('$tutorial_title', '$user_name', '$dt', '$vid_name_stored','$vid_type', '$img_name_stored', '$explanation', '$stream','0','$tut_attach_id');";
                    if (mysqli_query($con, $qry2)) {
                        echo "</br><center><h1 style=\"color:green\"> -----: Posted successfully 1 row inserted :----- </h1></center>";
                        move_uploaded_file($_FILES['video_file']['tmp_name'], "videos/$vid_name_stored");
                        move_uploaded_file($_FILES['image_file']['tmp_name'], "images/$img_name_stored");
                    } else {
                        echo'<h3 style="color:red">post failed. Issue : <i>' . mysqli_error($con) . '</i></h3><br/>';
                    }

                    $qry_get_tut_id = "SELECT tutorial_id from tutorial_section where tut_attach_id='$tut_attach_id';";
                    $res_get_id = mysqli_query($con, $qry_get_tut_id);
                    $row_get = mysqli_fetch_all($res_get_id, MYSQLI_NUM);
                    $got_tutorial_id = $row_get[0][0];

                    if ($attchments_name[0] == "") {

                        $zero_attach = "UPDATE `tutorial_section` SET `number_of_attachments` = '0' WHERE `tutorial_section`.`tutorial_id` =$got_tutorial_id;";
                        mysqli_query($con, $zero_attach);
                        echo "<center><h2>No attachments were added</h2></center>";
                    } else {
                        $num = count($attchments_name);
                        $no_of_attach = "UPDATE `tutorial_section` SET `number_of_attachments` = '$num' WHERE `tutorial_section`.`tutorial_id` =$got_tutorial_id;";
                        mysqli_query($con, $no_of_attach);
                        $attach_prefix = "tut_" . $tutorial_id . "_attachment_";
                        $i = 0;
                        foreach ($attchments_name as $attach_nm) {
                            $qry3 = "SELECT attachment_id from tutorial_attachments order by attachment_id desc";
                            $attach_id = 1;
                            $res3 = mysqli_query($con, $qry3);
                            $num_arr3 = mysqli_fetch_all($res3, MYSQLI_NUM);
                            $tot_rows3 = count($num_arr3);
                            if ($tot_rows3 > 0) {
                                $attach_id = $num_arr3[0][0];
                                $attach_id++;
                            }
                            $attach_stored_name = $attach_prefix . "$attach_id." . pathinfo($attach_nm, PATHINFO_EXTENSION);
                            $attach_nm = mysqli_real_escape_string($con, $attach_nm);

                            $qry4 = "INSERT INTO `tutorial_attachments` (`tutorial_id_foreign`, `file_name`, `stored_file_name`) VALUES ('$got_tutorial_id', '$attach_nm', '$attach_stored_name');";
                            if (mysqli_query($con, $qry4)) {
                                move_uploaded_file($attchments_temp[$i], "attachments/$attach_stored_name");
                            } else {
                                echo'<h3 style="color:red">Attachment failed. Issue : <i>' . mysqli_error($con) . '</i></h3><br/>';
                            }
                            $i++;
                        }
                        echo "</br><center><h2 style=\"color:green\"> -----: $num files were successfully attached:----- </h2></center>";
                    }
                    mysqli_close($con);
                    header("Location:index.php");
                }
            } else {
                header("Location:post_tutorial_ui.php");
            }
            ?>
            <a href="index.php"> Back to Tutorial section home page</a>
        </body>
    </html>
    <?php
} else {
    header("location:../login.php");
}
?>

