<?php
session_start();
include '../database_connect_parameters.inc';
if (isset($_SESSION['logged_in_user_name'])) {
    ?>
    <!DOCTYPE html>
    <html>
        <head>
            <title>Tutorial section home</title>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <script src="../libraries/jquery-3.1.1.min.js"></script>
            <script src="../libraries/smooth_scroll/jquery.easing.min.js"></script>
            <script src="../libraries/smooth_scroll/scrolling-nav.js"></script>
            <link href="../libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
            <link href="../libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
            <script src="../libraries/bootstrap/js/bootstrap.js"></script>
            <link href="../smooth_scroll/scrolling-nav.css" rel="stylesheet" />
        </head>

        <body style="padding-top:100px; padding-bottom: 100px; background-image:url(../OLS_Images/tutorial_section.jpg); background-size:100%;background-attachment:fixed;"> 

            <div id="top_nav_bar_vj">
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="container-fluid" style="background-color:<?php
                    if ($_SESSION['logged_in_user_account_type'] == 2) {
                        echo "#4caf50";
                    } else {
                        echo "#c84747";
                    }
                    ?>;font-variant-caps:all-petite-caps;">
                        <!--This gives enough padding for navbar elements-->
                        <div class="navbar-header" style="color:#ffffff;">
                            <button type="button" class="navbar-toggle" data-target="#resize_menu_vj_top" data-toggle="collapse">
                                <!-- To get THREE bars(Icon bars) when we resize the window to smaller size-->
                                <span class="glyphicon glyphicon-menu-hamburger"></span>
                                <span>Menu</span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse" id="resize_menu_vj_top">
                            <ul class="nav navbar-nav">
                                <li id="list_id_index"><a href="../index.php"><img src="../OLS_Images/home.jpg" width="50" height="50" style="border-radius:2px 18px" /><span style="color:#ffffff; font:initial; font-style:italic; font-size:xx-large;">&nbsp; Online Learning Suite</span></a></li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">                              
                                <li id="list_id_profile"><a href="../user_profile.php?user_name=<?php echo $_SESSION['logged_in_user_name']; ?>" target="_blank"><img src="../profile_pics/<?php echo $_SESSION['logged_in_user_profile_pic_name']; ?>" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; PROFILE</span></a></li>
                                <?php
                                // Posting link should be only for RESOURCE persons.
                                if ($_SESSION['logged_in_user_account_type'] == 2) {
                                    ?>

                                    <li id="list_id_post_a_tutorial"><a href="post_tutorial_ui.php" target='_blank'><img src="../OLS_Images/post_tutorial.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; POST A TUTORIAL </span></a></li>
                                    <li id="list_id_delete_a_tutorial"><a href="self_tutorial_delete_ui.php" target='_blank'><img src="../OLS_Images/delete.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; DELETE YOUR TUTORIAL </span></a></li>
                                <?php }
                                ?>  

                                <li id="list_id_logout"><a href="../logout.php"><img src="../OLS_Images/logout.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; LOGOUT</span></a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>

            <?php
            $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
            if (!$con) {
                die('Could not connect to database : ' . mysql_error());
                exit(1);
            }
            ?>
            <div class="container">
                <div class="row">
                    <div class="col-md-10">
                        <div class="custom_div" style="background-color: #ffffff;padding: 30px 30px 30px 30px;border-radius:10px; box-shadow:0 1px 60px <?php
                        if ($_SESSION['logged_in_user_account_type'] == 2) {
                            echo "rgb(76, 175, 80)";
                        } else {
                            echo "rgb(200, 71, 71)";
                        }
                        ?>;">
                             <?php
                             $attachments = "";
                             $video_available = "";
                             $image_avaliable = "";
                             $qry1 = "";
                             $stream = $_SESSION['logged_in_user_stream'];
                             if (empty($_REQUEST)) {
                                 $qry1 = "select * from tutorial_section where stream='$stream' order by posted_date desc;";
                             } else {
                                 $tutorial_id = $_REQUEST['tutorial_id'];
                                 $qry1 = "select * from tutorial_section where tutorial_id='$tutorial_id' and stream='$stream';";
                             }
                             $res1 = mysqli_query($con, $qry1);
                             $row1 = mysqli_fetch_array($res1);
                             $current_tutorial_id = $row1['tutorial_id'];
                             $current_title = htmlentities($row1['tutorial_title'], ENT_QUOTES);
                             $current_user_name = htmlentities($row1['user_name'], ENT_QUOTES);
                             $current_posted_date = $row1['posted_date'];
                             $current_video_path = $row1['video_path'];
                             $current_image_path = $row1['image_path'];
                             $current_explanation = htmlentities($row1['explanation'], ENT_QUOTES);
                             $current_stream = $row1['stream'];
                             $current_number_of_attachments = $row1['number_of_attachments'];

                             //video/audio block with image block
                             if ($current_video_path != "") {
                                 if ($current_image_path != "") {
                                     $image_avaliable = "<div id='image_block' style='text-align:left' title='Image block'><ul><li> <button id='image_button' class='btn-link' onclick='view_image()'>VIEW IMAGE</button></li><li> <a href='images/$current_image_path' target='_blank'>&nbsp; VIEW IMAGE IN NEW TAB </a></li></ul> <script type='text/javascript'>  var status = 0; function view_image() {  if (status == 0) {  document.getElementById('image_display_div').innerHTML = \"<img src='images/$current_image_path' width='900' height='700'/>\"; status = 1; document.getElementById('image_button').innerHTML = \"HIDE IMAGE\"; }  else { document.getElementById('image_display_div').innerHTML = ''; status = 0;  document.getElementById('image_button').innerHTML = \"VIEW IMAGE\";  }   } </script>  <div id='image_display_div'>  </div> </div>";
                                 } else {
                                     $image_avaliable = "";
                                 }
                                 $video_available = "<div id='video_block'><video controls autoplay width='890' height='530' poster='../file_icons/video.png'> <source src='videos/$current_video_path' /> </video></div>";
                             } else {
                                 if ($current_image_path != "") {
                                     $image_avaliable = "<div id='image_block' style='text-align:left' title='Image block'><ul><li> <button id='image_button' class='btn-link' onclick='view_image()'>VIEW IMAGE</button></li><li> <a href='images/$current_image_path' target='_blank'>&nbsp; VIEW IMAGE IN NEW TAB </a></li></ul> <script type='text/javascript'>  var status = 0; function view_image() {  if (status == 0) {  document.getElementById('image_display_div').innerHTML = \"<img src='images/$current_image_path' width='900' height='700'/>\"; status = 1; document.getElementById('image_button').innerHTML = \"HIDE IMAGE\"; }  else { document.getElementById('image_display_div').innerHTML = ''; status = 0;  document.getElementById('image_button').innerHTML = \"VIEW IMAGE\";  }   } </script>  <div id='image_display_div'>  </div> </div>";
                                 } else {
                                     $image_avaliable = "";
                                 }
                                 $video_available = "";
                             }
                             //Attachments blocks
                             if ($current_number_of_attachments > 0) {
                                 $qry2 = "select * from tutorial_attachments where tutorial_id_foreign=$current_tutorial_id";
                                 $res2 = mysqli_query($con, $qry2);
                                 $attachments = "<h3 style='color:green;text-align:left'>Attachments : $current_number_of_attachments </h3><ol style='text-align:left'>";
                                 while ($row2 = mysqli_fetch_array($res2)) {
                                     $attachments .= "<li><a href='attachments/" . $row2['stored_file_name'] . "' target='_blank'>" . $row2['file_name'] . "</a></li>";
                                 }
                                 $attachments .= "</ol>";
                             } else {
                                 $attachments = "";
                             }
                             $date_javascript_str = "<script type='text/javascript'> var dtjs = new Date('$current_posted_date'); document.write(dtjs.toDateString()); document.write(' at '+dtjs.toLocaleTimeString()); </script>"; // Converting date to MORE READABLE form by using javascript
                             $posted_uploder = "<div style='text-align:right'>Posted by : <span style='color:red'>$current_user_name&nbsp;&nbsp;</span><br/>Posted on : <span style='color:red'>$date_javascript_str&nbsp;&nbsp;</span></div>";
                             $expl = "<div style='text-align:justify;'><pre style='font:inherit;'>$current_explanation</pre></div>";
                             ?>

                            <div style="width:inherit;" title="<?php echo $current_title; ?>">
                                <?php
                                echo "<h2 style='text-align:center;'>$current_title</h2><hr>";
                                echo $video_available . "<hr>";
                                echo $posted_uploder . "<hr>";
                                echo $image_avaliable . "<br>";
                                echo $expl . "<br>";
                                echo $attachments . "<br>";
                                ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="custom_div">
                            <div id="ajax_change">
                                <ul class="list-unstyled">
                                    <?php
                                    $qry3 = "select * from tutorial_section where stream='$stream' order by posted_date desc";  // get the recent posts first                                     
                                    $res3 = mysqli_query($con, $qry3);
                                    while ($row3 = mysqli_fetch_array($res3)) {
                                        $title = $row3['tutorial_title'];
                                        $tutorial_id_side_list = $row3['tutorial_id'];
                                        $short_title = $title;
                                        if (strlen($title) > 30) {
                                            $split_arr = str_split($title, 30); // Splits the string into several parts based on specified split length in this example split_length=42
                                            $short_title = $split_arr[0]; // First split part
                                            $short_title = $short_title . "..."; //Appending 3 dots to show continuation of file name
                                        }
                                        $type = strtok($row3['type'], '/');
                                        $thumbnail = "";
                                        if (strcasecmp($type, "video") == 0) {
                                            $thumbnail = "../file_icons/video.png";
                                        } elseif (strcasecmp($type, "audio") == 0) {
                                            $thumbnail = "../file_icons/audio.png";
                                        } else {
                                            $thumbnail = "../file_icons/unknown.png";
                                        }
                                        $title = htmlentities($title, ENT_QUOTES);
                                        $short_title = htmlentities($short_title, ENT_QUOTES);
                                        ?>
                                        <li>
                                            <div style="background-color:#ffffff; padding: 10px 10px 10px 10px; width:inherit; height:220px;word-break:break-all;border-radius:10px; box-shadow:0 1px 60px <?php
                                            if ($_SESSION['logged_in_user_account_type'] == 2) {
                                                echo "rgb(76, 175, 80)";
                                            } else {
                                                echo "rgb(200, 71, 71)";
                                            }
                                            ?>;" title="<?php echo $title; ?>">
                                                <a href="index.php?tutorial_id=<?php echo $tutorial_id_side_list; ?>">
                                                    <img src="<?php echo $thumbnail; ?>" width="150" height="150" /><br/>
                                                    <span><?php echo $short_title; ?></span>
                                                </a>
                                            </div>
                                            <br/>
                                        </li>
                                        <?php
                                    }
                                    ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            mysqli_close($con);
            ?>
        </body>
    </html>
    <?php
} else {
    header("location:../login.php");
}
?>