<?php
session_start();
include 'database_connect_parameters.inc';
if (isset($_SESSION['logged_in_user_name'])) {
    $u_name = $_SESSION['logged_in_user_name'];
    //Database connection
    $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
    if (!$con) {
        die('Could not connect to database: ' . mysql_error());
        exit(14);
    }

    $qry1 = "SELECT * FROM `user_accounts` where user_name='$u_name';";
    $res1 = mysqli_query($con, $qry1);
    while ($row = mysqli_fetch_array($res1)) {
        $read_user_name = htmlentities($row['user_name'], ENT_QUOTES);
        $read_full_name = htmlentities($row['full_name'], ENT_QUOTES);
        $read_stream = $row['stream'];
        $read_ac_tp = $row['account_type'];
        $read_email = $row['email'];
        $read_sx = $row['sex'];
        $read_reg_on = $row['registered_on'];
        $read_profile_pic_name = htmlentities($row['profile_pic_name'], ENT_QUOTES);

        $registered_on = "<script type='text/javascript'> var dtjs = new Date('$read_reg_on'); document.write(dtjs.toDateString()); document.write(' at '+dtjs.toLocaleTimeString()); </script>"; // Converting date to MORE READABLE form by using javascript
        $sex = "";
        $account_type = "";
        $stream = "";
        switch ($read_stream) {
            case 1: $stream = "Computer Science";
                break;
            case 2: $stream = "Information Science";
                break;
            case 3: $stream = "Civil Engineering";
                break;
            case 4: $stream = "Mechanical Engineering";
                break;
            case 5: $stream = "Electronics Engineering";
                break;
            case 6: $stream = "Other";
                break;
            default : $stream = "";
                break;
        }
        if ($read_sx == 0) {
            $sex = "Male";
        } else {
            $sex = "Female";
        }
        if ($read_ac_tp == 1) {
            $account_type = "Learner/student";
        } else {
            $account_type = "Resource person";
        }
        ?>
        <html>
            <head>
                <title>Profile -<?php echo $read_full_name; ?> </title>
                <script src="libraries/jquery-3.1.1.min.js"></script>
                <script src="libraries/smooth_scroll/jquery.easing.min.js"></script>
                <script src="libraries/smooth_scroll/scrolling-nav.js"></script>
                <link href="libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
                <link href="libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
                <script src="libraries/bootstrap/js/bootstrap.js"></script>
                <link href="smooth_scroll/scrolling-nav.css" rel="stylesheet" />
            </head>   

            <body style="padding-top:120px; background-image:url(OLS_Images/home_background.jpg); background-size:100%;background-attachment:fixed;">
                <!--Style By Vijay-->
                <div id="top_nav_bar_vj">
                    <nav class="navbar navbar-default navbar-fixed-top">
                        <div class="container-fluid" style="background-color:<?php
                        if ($_SESSION['logged_in_user_account_type'] == 2) {
                            echo "#4caf50";
                        } else {
                            echo "#c84747";
                        }
                        ?>;font-variant-caps:all-petite-caps;">
                            <!--This gives enough padding for navbar elements-->
                            <div class="navbar-header" style="color:#ffffff;">
                                <button type="button" class="navbar-toggle" data-target="#resize_menu_vj_top" data-toggle="collapse">
                                    <!-- To get THREE bars(Icon bars) when we resize the window to smaller size-->
                                    <span class="glyphicon glyphicon-menu-hamburger"></span>
                                    <span>Menu</span>
                                </button>
                            </div>
                            <div class="navbar-collapse collapse" id="resize_menu_vj_top">
                                <ul class="nav navbar-nav">
                                    <li id="list_id_index"><a class="page-scroll" href="index.php"><img src="OLS_Images/home.jpg" width="50" height="50" style="border-radius:2px 18px" /><span style="color:#ffffff; font:initial; font-style:italic; font-size:xx-large;">&nbsp; Online Learning Suite</span></a></li>
                                </ul>
                                <ul class="nav navbar-nav navbar-right">                            
                                    <li id="list_id_profile"><a href="user_profile.php?user_name=<?php echo $_SESSION['logged_in_user_name']; ?>"><img src="profile_pics/<?php echo $_SESSION['logged_in_user_profile_pic_name']; ?>" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; PROFILE</span></a></li>
                                    <li id="list_id_logout"><a href="logout.php"><img src="OLS_Images/logout.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; LOGOUT</span></a></li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                </div>


                <div class="container" style="padding:50px 50px 50px 50px;background-color:white;border-radius:20px 20px; box-shadow:0 1px 20px <?php
                if ($_SESSION['logged_in_user_account_type'] == 2) {
                    echo "rgb(76, 175, 80)";
                } else {
                    echo "rgb(200, 71, 71)";
                }
                ?>;">

                    <div class="row">
                        <div class="col-md-4" style="text-align:center;">
                            <img src="profile_pics/<?php echo "$read_profile_pic_name"; ?>" height="200" height="200"  alt="profile picture" style="border:solid greenyellow thick;border-radius:20px 20px; box-shadow:0 1px 20px rgb(76,175,80);"/>
                            <br/>
                            <br/>
                            <a href="upload_profile_pic.php" class="btn btn-primary">Upload new profile picture</a>
                        </div>
                        <div class="col-md-8">
                            <table class="table" style="text-align:left;">
                                <tr>
                                    <td><h2 style="color:#000099">Full Name</h2></td><td><h2><?php echo $read_full_name; ?></h2></td>
                                </tr>
                                <tr>
                                    <td><h2 style="color:#000099">User Name</h2></td><td><h2><?php echo $read_user_name; ?></h2></td>
                                </tr>
                                <tr>
                                    <td><h2 style="color:#000099">Account Type</h2></td><td><h2><?php echo $account_type; ?></h2></td>
                                </tr>
                                <tr>
                                    <td><h2 style="color:#000099">Stream</h2></td><td><h2><?php echo $stream; ?></h2></td>
                                </tr>
                                <tr>
                                    <td><h2 style="color:#000099">Email - ID</h2></td><td><h2><?php echo $read_email; ?></h2></td>
                                </tr>
                                <tr>
                                    <td><h2 style="color:#000099">Sex</h2></td><td><h2><?php echo $sex ?></h2></td>
                                </tr>
                                <tr>
                                    <td><h2 style="color:#000099">Registered On</h2></td><td><h2><?php echo $registered_on; ?></h2></td>
                                </tr>

                            </table>

                        </div>
                    </div>

                </div>

            </body>
        </html>
        <?php
    }
    mysqli_close($con);
} else {
    header("location:login.php");
}
?>