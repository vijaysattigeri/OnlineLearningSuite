<?php
session_start();
include '../database_connect_parameters.inc';
if (isset($_SESSION['logged_in_maintain_user'])) {
    ?>

    <html>
        <head>
            <title>Resource administrator</title>
            <script src="../libraries/jquery-3.1.1.min.js"></script>
            <script src="../libraries/smooth_scroll/jquery.easing.min.js"></script>
            <script src="../libraries/smooth_scroll/scrolling-nav.js"></script>
            <link href="../libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
            <link href="../libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
            <script src="../libraries/bootstrap/js/bootstrap.js"></script>
            <link href="../smooth_scroll/scrolling-nav.css" rel="stylesheet" />
        </head>

        <body style="padding-top:140px; background-image:url(../OLS_Images/maintain_bg.jpg); background-size:100%;background-attachment:fixed;">
            <!--Style By Vijay-->

            <div id="top_nav_bar_vj">
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="container-fluid" style="background-color:#0080ff;font-variant-caps:all-petite-caps;">
                        <!--This gives enough padding for navbar elements-->
                        <div class="navbar-header" style="color:#ffffff;">
                            <button type="button" class="navbar-toggle" data-target="#resize_menu_vj_top" data-toggle="collapse">
                                <!-- To get THREE bars(Icon bars) when we resize the window to smaller size-->
                                <span class="glyphicon glyphicon-menu-hamburger"></span>
                                <span>Menu</span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse" id="resize_menu_vj_top">
                            <ul class="nav navbar-nav">
                                <li id="list_id_index"><a class="page-scroll" href="../maintenance_team.php"><img src="../OLS_Images/settings.jpg" width="50" height="50" style="border-radius:2px 18px" /><span style="color:#ffffff; font:initial; font-style:italic; font-size:xx-large;">&nbsp; OLS Maintenance home</span></a></li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">                                
                                <li id="list_id_logout"><a href="../logout.php"><img src="../OLS_Images/logout.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; LOGOUT</span></a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
            <div class="container" style="padding:150px 150px 150px 150px; text-align: center; background-color:white;border-radius:20px 20px; box-shadow:0 1px 100px rgb(200, 71, 71);">

                <form action="maintain_resource.php" method="post">
                    <div class="row">
                        <div class="col-md-4">
                            <h4> Choose validation type : </h4>
                        </div>
                        <div class="col-md-4">
                            <select name="delete_option" class="form-control">
                                <option value="0">Validate pending files</option>
                                <option value="1">Delete previous files</option>                
                            </select>
                        </div>
                        <div class="col-md-4">
                            <input type="submit" name="sub" value="Submit" class="btn btn-primary"/>
                        </div>
                    </div>             
                </form>                
            </div>
        </body>
    </html>

    <?php
} else {
    header("location:../login.php");
}
?>