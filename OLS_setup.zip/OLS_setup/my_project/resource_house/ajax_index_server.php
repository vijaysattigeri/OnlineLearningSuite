<?php

session_start();
include '../database_connect_parameters.inc';
if (isset($_SESSION['logged_in_user_name'])) {


    $stream = $_SESSION['logged_in_user_stream'];
    $sort_factor = $_REQUEST['sort_factor'];
    $sort_order = $_REQUEST['sort_order'];
    $qry = "";
    $empty_flag = 1;
    $ajax_return = "<ul class='list-unstyled list-inline'>";

    $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
    if (!$con) {
        die('Could not connect: ' . mysql_error());
    }

    if ($stream == 0) {
        $qry = "select file_name,stored_file_name,file_type,category from resource_house where valid='1' order by $sort_factor $sort_order";  // get the recent uploads first 
    } else {
        $qry = "select file_name,stored_file_name,file_type,category from resource_house where valid='1' and stream='$stream' order by $sort_factor $sort_order";  // get the recent uploads first
    }

    $result = mysqli_query($con, $qry);


    while ($row = mysqli_fetch_array($result)) {
        $empty_flag = 0;
        $stored_file_name = $row['stored_file_name'];
        $output_val = $row['file_name'];
        if (strlen($output_val) > 60) {
            $split_arr = str_split($output_val, 60); // Splits the string into several parts based on specified split length in this example split_length=42
            $output_val = $split_arr[0]; // First split part
            $output_val = $output_val . "..."; //Appending 3 dots to show continuation of file name
        }
        $output_val = htmlentities($output_val, ENT_QUOTES); //Converts special characters to HTML special characters like <,>,'',"" etc 
        //file icon setting
        $file_icon = "../file_icons/";
        $type = $row['file_type'];
        $category = strtok($row['category'], '/');

        if (strcasecmp($category, "video") == 0) {
            $file_icon .= "../file_icons/video.png";
        } elseif (strcasecmp($category, "audio") == 0) {
            $file_icon .= "../file_icons/audio.png";
        } elseif (strcasecmp($category, "image") == 0) {
            $file_icon .= "../file_icons/image.png";
        } else {

            switch (strtolower($type)) {
                case "pdf" : $file_icon .= "pdf.png";
                    break;
                default : $file_icon .= "unknown.png";
                    break;
            }
        }
        $border_color = "#ffffff";
        $box_shadow = "0 1px 20px rgb(200, 71, 71)";
        if ($_SESSION['logged_in_user_account_type'] == 2) {
            $box_shadow = "0 1px 20px rgb(76, 175, 80)";
        }
        $ajax_return .= "<li><a href='detail_download_page.php?stored_file_name=$stored_file_name' target='_blank'><div style='padding:10px 10px 10px 10px; width:225px; height:270px; word-break:break-all; border:solid; border-color:$border_color; border-radius:16px; box-shadow:$box_shadow;' title='$output_val'><div id='img_div' style='margin-left:10px;margin-top:5px;'><img src='$file_icon' width='160' height='160' /></div><br /><span style='margin-left:5px;font:bold 14px verdana;'>$output_val</span></div></a><br /></li>"; //<br /><li> MUST include the break to the LIST ITEM. If not itmes will not arrange properly
    }

    $ajax_return .= "</ul></div>";
    if ($empty_flag == 1) {
        $ajax_return = "<h2 style='color:red'>No files found</h2>";
    }
    echo $ajax_return;
    mysqli_close($con);
} else {
    header("location:../login.php");
}
?>