<?php
session_start();
include '../database_connect_parameters.inc';
if (isset($_SESSION['logged_in_user_name'])) {
    ?>
    <!DOCTYPE html>
    <html>
        <head>
            <title> Resource house home</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <script src="../libraries/jquery-3.1.1.min.js"></script>
            <script src="../libraries/smooth_scroll/jquery.easing.min.js"></script>
            <script src="../libraries/smooth_scroll/scrolling-nav.js"></script>
            <link href="../libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
            <link href="../libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
            <script src="../libraries/bootstrap/js/bootstrap.js"></script>
            <link href="../smooth_scroll/scrolling-nav.css" rel="stylesheet" />

            <script type="text/javascript">
                function sort_data() {
                    var s1 = document.getElementById('sort_factor').value;
                    var s2 = document.getElementById('sort_order').value;
                    var str = "sort_factor=" + s1 + "&sort_order=" + s2;
                    if (window.XMLHttpRequest) { // code for IE7+, Firefox, Chrome, Opera, Safari
                        xmlhttp = new XMLHttpRequest();
                    } else { // code for IE6, IE5
                        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    xmlhttp.onreadystatechange = function () {
                        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                            document.getElementById("ajax_change").innerHTML = xmlhttp.responseText;
                        }
                    }
                    xmlhttp.open("GET", "ajax_index_server.php?" + str, true);
                    xmlhttp.send();
                }
            </script> 
        </head>

        <body style="padding-top:100px; padding-bottom: 100px; background-image:url(../OLS_Images/tutorial_section.jpg); background-size:100%;background-attachment:fixed;"> 

            <div id="top_nav_bar_vj">
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="container-fluid" style="background-color:<?php
                    if ($_SESSION['logged_in_user_account_type'] == 2) {
                        echo "#4caf50";
                    } else {
                        echo "#c84747";
                    }
                    ?>;font-variant-caps:all-petite-caps;">
                        <!--This gives enough padding for navbar elements-->
                        <div class="navbar-header" style="color:#ffffff;">
                            <button type="button" class="navbar-toggle" data-target="#resize_menu_vj_top" data-toggle="collapse">
                                <!-- To get THREE bars(Icon bars) when we resize the window to smaller size-->
                                <span class="glyphicon glyphicon-menu-hamburger"></span>
                                <span>Menu</span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse" id="resize_menu_vj_top">
                            <ul class="nav navbar-nav">
                                <li id="list_id_index"><a href="../index.php"><img src="../OLS_Images/home.jpg" width="50" height="50" style="border-radius:2px 18px" /><span style="color:#ffffff; font:initial; font-style:italic; font-size:xx-large;">&nbsp; Online Learning Suite</span></a></li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">                              
                                <li id="list_id_profile"><a href="../user_profile.php?user_name=<?php echo $_SESSION['logged_in_user_name']; ?>" target="_blank"><img src="../profile_pics/<?php echo $_SESSION['logged_in_user_profile_pic_name']; ?>" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; PROFILE</span></a></li>
                                <li id="list_id_upload_file"><a href="upload_dialog.php"><img src="../OLS_Images/upload.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; UPLOAD A FILE</span></a></li>
                                <li id="list_id_delete_file"><a href="self_resource_delete_ui.php"><img src="../OLS_Images/delete.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; DELETE YOUR FILES</span></a></li>                                
                                <li id="list_id_logout"><a href="../logout.php"><img src="../OLS_Images/logout.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; LOGOUT</span></a></li>                                 
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>

            <div class="container" style="background-color:#ffffff;padding: 30px 30px 30px 30px; border-radius:10px; box-shadow:0 1px 60px <?php
            if ($_SESSION['logged_in_user_account_type'] == 2) {
                echo "rgb(76, 175, 80)";
            } else {
                echo "rgb(200, 71, 71)";
            }
            ?>;"> 

                <div id="sorting_div" style="padding-bottom:50px;">
                    <form>
                        <div class="row">
                            <div class="col-md-3">
                                <h4>Select the sort factors </h4>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <select id="sort_factor" class="form-control">
                                        <option value="upload_date">Upload date</option>
                                        <option value="download_count">Number of downloads</option> 
                                        <option value="file_size">size</option> 
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <select id="sort_order" class="form-control">
                                        <option value="desc">Descending</option>  
                                        <option value="asc">Ascending</option>                                      
                                    </select>                                    
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">                                  
                                    <input type="button" value="SORT" onclick="sort_data()" class="btn btn-primary" />
                                </div>

                            </div> 
                        </div>
                    </form>
                </div>
                <hr/>
                <div class="row"><div class="col-md-12"> <!-- Bootstrap grid system-->                        
                        <?php
                        $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
                        if (!$con) {
                            die('Could not connect: ' . mysql_error());
                        }
                        $stream = $_SESSION['logged_in_user_stream'];
                        $qry = "select file_name,stored_file_name,file_type,category from resource_house where valid='1' and stream='$stream' order by upload_date desc";  // get the recent uploads first
                        $result = mysqli_query($con, $qry);

                        $out_res = "<div id='ajax_change'><ul class='list-unstyled list-inline'>";
                        while ($row = mysqli_fetch_array($result)) {
                            $stored_file_name = $row['stored_file_name'];
                            $output_val = $row['file_name'];
                            if (strlen($output_val) > 60) {
                                $split_arr = str_split($output_val, 60); // Splits the string into several parts based on specified split length in this example split_length=42
                                $output_val = $split_arr[0]; // First split part
                                $output_val = $output_val . "..."; //Appending 3 dots to show continuation of file name
                            }
                            $output_val = htmlentities($output_val, ENT_QUOTES); //Converts special characters to HTML special characters like <,>,'',"" etc 
                            //file icon setting
                            $file_icon = "../file_icons/";
                            $type = $row['file_type'];
                            $category = strtok($row['category'], '/');

                            if (strcasecmp($category, "video") == 0) {
                                $file_icon .= "../file_icons/video.png";
                            } elseif (strcasecmp($category, "audio") == 0) {
                                $file_icon .= "../file_icons/audio.png";
                            } elseif (strcasecmp($category, "image") == 0) {
                                $file_icon .= "../file_icons/image.png";
                            } else {

                                switch (strtolower($type)) {
                                    case "pdf" : $file_icon .= "pdf.png";
                                        break;
                                    default : $file_icon .= "unknown.png";
                                        break;
                                }
                            }

                            $border_color = "#ffffff";
                            $box_shadow = "0 1px 20px rgb(200, 71, 71)";
                            if ($_SESSION['logged_in_user_account_type'] == 2) {
                                $box_shadow = "0 1px 20px rgb(76, 175, 80)";
                            }
                            $out_res .= "<li><a href='detail_download_page.php?stored_file_name=$stored_file_name' target='_blank'><div style='padding:10px 10px 10px 10px;width:225px; height:270px; word-break:break-all; border:solid; border-color:$border_color; border-radius:16px; box-shadow:$box_shadow;' title='$output_val'><div id='img_div' style='margin-left:10px;margin-top:5px;'><img src='$file_icon' width='160' height='160' /></div><br /><span style='margin-left:5px;font:bold 14px verdana;'>$output_val</span></div></a><br /></li>"; //<br /><li> MUST include the break to the LIST ITEM. If not itmes will not arrange properly
                        }
                        $out_res .= "</ul></div>";
                        echo $out_res;
                        mysqli_close($con);
                        ?>
                    </div>
                </div>

            </div> 
        </body>
    </html>
    <?php
} else {
    header("location:../login.php");
}
?>