<?php

session_start();
include '../database_connect_parameters.inc';

if (isset($_SESSION['logged_in_user_name'])) {

    if (isset($_REQUEST['submit_upload_form'])) {
// Obtain Uploaded file details
        $size = $_FILES['file_input_vj']['size'];
        $file_name = $_FILES['file_input_vj']['name'];
        $category = $_FILES['file_input_vj']['type'];
        $error = $_FILES['file_input_vj']['error'];
        $err_no = $error;
        $type = pathinfo($file_name, PATHINFO_EXTENSION);  // To get file extension

        if ($file_name == "") {
            header("Location:upload_dialog.php");
            // if the file is not selected then script is REDIRECTED to the form page = upload_dialog.html 
        }

//Checking permissible file type
        $valid_type = array("pdf", "jpeg", "jpg", "png", "txt", "docx", "doc", "mp3", "mp4", "rar", "zip");
        $invalid_type_flag = 1;
        foreach ($valid_type as $tp) {
            if (strcasecmp($type, $tp) == 0) {
                $invalid_type_flag = 0;
            }
        }

//Uploaded file error.
        if ($err_no != 0) {

            switch ($err_no) {
                case 0: $error = "<span style='color:green'>NO error : UPLOAD_ERR_OK :  Status :  OK</span>";
                    break;
                case 1: $error = "<span style='color:red'>ERROR : UPLOAD_ERR_INI_SIZE: File size is more than maximum specified limit.</span>";
                    break;
                case 2: $error = "<span style='color:red'>ERROR : UPLOAD_ERR_FORM_SIZE : File size eceeding max. POST size of HTML form</span>";
                    break;
                case 3: $error = "<span style='color:red'>ERROR : UPLOAD_ERR_PARTIAL : Partial file upload error due to network failure</span>";
                    break;
                case 4: $error = "<span style='color:red'>ERROR : UPLOAD_ERR_NO_FILE : No file is selected</span>";
                    break;
                default : $error = "UNSPECIFIED ERROR : Some error occured..";
                    break;
            }
        }

//File size check
        $max_size = (50 * 1024 * 1024);
        $size_invalid = 0;
        if ($size > $max_size || $size == 0) {
            $size_invalid = 1;
        }

        if ($err_no != 0 || $invalid_type_flag == 1 || $size_invalid == 1) {
            $err1 = "";
            $err2 = "";
            $err3 = "";
            if ($err_no != 0) {
                $errr1 = $error;
            }
            if ($invalid_type_flag == 1) {
                $err2 = "Illegeal file. permissible files are :(pdf,jpeg,jpg,png,txt,docx,doc,mp3,mp4)";
            }
            if ($size_invalid == 1) {
                $err3 = "File is too large or too small. Maximum : Minimum file size is = 50MB : 1B ";
            }
            echo "<html><head><title>INPUT ERROR</title></head><body><h2 style='color:red'>ERROR LIST :-----</br> </h2><ul style='color:red'><li>$err1</li><li>$err2</li><li>$err3</li></ul>";
            echo"<a href='upload_dialog.php'>Back to upload page</a><br/><br/><a href='index.php'>Resource House</a></body></html>";
        } else {  // If all parameters are valid.
// Connection
            $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
            if (!$con) {
                die('Could not connect: ' . mysql_error());
                exit(14);
            }

// To generate file names to be stored
            $qry1 = "SELECT id from resource_house order by id desc";
            $id = 1;
            $res1 = mysqli_query($con, $qry1);
            $num_arr = mysqli_fetch_all($res1, MYSQLI_NUM);
            $tot_rows = count($num_arr);
            if ($tot_rows > 0) {
                $id = $num_arr[0][0];
                $id++;
            }
            $stored_file_name = $type . $id . ".$type";
            $file_name = mysqli_real_escape_string($con, $file_name); // To provide a valid file name IDENTIFIER.
            //Actual file upload code
            move_uploaded_file($_FILES['file_input_vj']['tmp_name'], "uploads/$stored_file_name"); // first argument for above program must be temporary file name else copy will not happen
            // Database Entry
            $path = "uploads/" . $stored_file_name;
            date_default_timezone_set("Asia/Kolkata"); //Refer PHP documentation manual. Navigate to "PHP Manual-> List of Supported Timezones->Asia
            $dt = date('Y-m-d H:i:s'); // to get upload date in the format that MySQL accepts
            $desc = mysqli_real_escape_string($con, $_REQUEST['description']);
            $stream = $_SESSION['logged_in_user_stream'];
            $user = $_SESSION['logged_in_user_name'];

            $qry_2 = "INSERT INTO `resource_house` (`file_name`,`stored_file_name`,`user_name`, `file_path`, `upload_date`, `download_count`, `file_size`, `file_type`, `stream`,`description`,`category`,`valid`) VALUES ('$file_name','$stored_file_name','$user', '$path', '$dt', '0', '$size', '$type', '$stream','$desc','$category','0')";
            if (mysqli_query($con, $qry_2)) {
                //File uploading successful so redirect to RESOURCE HOUSE home
                header("location:index.php");
            } else {
                echo'<h3 style="color:red">Insertion failed. Issue : <i>' . mysqli_error($con) . '</i></h3><br/>';
            }
            mysqli_close($con);
        }
    } else {
        header("location:index.php");
    }
} else {
    header("location:../login.php");
}
?>