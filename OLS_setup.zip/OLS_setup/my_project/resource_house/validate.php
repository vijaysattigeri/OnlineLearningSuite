<?php
session_start();
include '../database_connect_parameters.inc';
if (isset($_SESSION['logged_in_maintain_user'])) {
    ?>

    <html>
        <head>
            <title>Monitor-invalid filter</title>
            <script type='text/javascript'>
                function time_load() {
                    setTimeout(redirect, 5000);
                }
                function redirect() {
                    window.location.href = 'index.php';
                }</script>
        </head>
        <body onload="time_load()">
            <?php
            if (isset($_REQUEST['file_id']) && isset($_REQUEST['submit_invalid'])) {
                $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);

                if (!$con) {
                    die('Could not connect: ' . mysql_error());
                }

                //read the path of specified file from the database and delete those files from "uploads" folder

                $deleted_file;
                $i = 0;
                $del_failed_files = 0;
                foreach ($_REQUEST['file_id'] as $id) {
                    $qry = "select file_name,file_path from resource_house where id='$id'";
                    $result = mysqli_query($con, $qry);
                    while ($row = mysqli_fetch_array($result)) {
                        if (unlink($row['file_path'])) {
                            $deleted_files[$i++] = $row['file_name'];
                        } else {
                            $del_failed_files++;
                        }
                    }
                }
                $success_rows = 0;
                $failure_rows = 0;
                foreach ($_REQUEST['file_id'] as $id) {
                    $qry = "DELETE FROM `resource_house` WHERE `resource_house`.`id` = '$id'";
                    $r1 = mysqli_query($con, $qry);
                    if ($r1 == TRUE) {
                        $success_rows++;
                    } else {
                        $failure_rows++;
                    }
                }


                // make remianing entries as valid
                $valid_enry = "UPDATE `resource_house` SET `valid` = '1' WHERE `resource_house`.`valid` = 0;";
                $update_valid = 0;
                if (mysqli_query($con, $valid_enry)) {
                    $update_valid = mysqli_affected_rows($con);
                }
                mysqli_close($con);
                $del_str = "";
                $i = 1;
                foreach ($deleted_files as $del) {
                    $del_str .= "($i) $del<br/>";
                    $i++;
                }
                $report = "<center><h1>-: REPORT :-</h1><table border=border cellspacing='0' cellpadding='10'>";
                $report .= "<tr><th align='left'>Number of files deleted</th><td>" . count($deleted_files) . "</td></tr>";
                $report .= "<tr><th align='left'>Number of deletion FAILED files</th><td>" . $del_failed_files . "</td></tr>";
                $report .= "<tr><th align='left'>Deleted files are</th><td>" . $del_str . "</td></tr>";
                $report .= "<tr><th align='left'>Number of rows deleted in database</th> <td>" . $success_rows . "</td></tr>";
                $report .= "<tr><th align='left'>Number of rows deletion ERROR in database</th><td>" . $failure_rows . "</td></tr>";
                $report .= "<tr><th align='left'>Number of rows made as VALID</th><td>" . $update_valid . "</td></tr>";
                $report .= "</table><br/><br/><h2 style='color:red'>In 5 seconds the page will be redirected</h2></center><a href='resource_admin.php'>Back to resource house administration</a></body></html>";
                echo "<br/>$report</br>";
            } else if (isset($_REQUEST['all_valid'])) {
                $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);

                if (!$con) {
                    die('Could not connect: ' . mysql_error());
                }

                $valid_enry = "UPDATE `resource_house` SET `valid` = '1' WHERE `resource_house`.`valid` = 0;";
                $all_va = 0;
                if (mysqli_query($con, $valid_enry)) {
                    $all_va = mysqli_affected_rows($con);
                }
                echo "<center><h1>-: Reoprt :-</h1><b>Number of rows made as valid are : $all_va</b><br/><h2 style='color:red'>In 5 seconds the page will be redirected</h2></center><a href='resource_admin.php'>Back to resource house administration</a></body></html>";
            } else {
                // redirect to the maintain_resource.php
                header("Location:maintain_resource.php");
            }
            ?>

            <?php
        } else {
            header("location:../login.php");
        }
        ?>