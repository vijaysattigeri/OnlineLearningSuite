<?php

session_start();
include '../database_connect_parameters.inc';

if (isset($_SESSION['logged_in_user_name'])) {

    $file_path = "uploads/" . $_GET['stored_file_name']; // Uploaded files are placed in "uploads" DIRECTORY
    $stored_file_name = $_GET['stored_file_name'];

    $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);

    if (!$con) {
        die('Could not connect: ' . mysql_error());
    }

    $sel_qry = "select file_name,download_count from resource_house where stored_file_name='$stored_file_name';";
    $result = mysqli_query($con, $sel_qry);
    $download_count = 0;
    $file_name = "";
    while ($row = mysqli_fetch_array($result)) {
        $download_count = $row['download_count'];
        $file_name = $row['file_name'];
    }

    $download_count++;

    $update_qry = "UPDATE `resource_house` SET `download_count` = '$download_count' WHERE `resource_house`.`stored_file_name` = '$stored_file_name'";
    mysqli_query($con, $update_qry);

    mysqli_close($con);

    $file_name = urlencode($file_name); // Some browsers(Mozilla FireFox) do NOT parse file name correctly if it contains white spaces and other special characters.
// Do NOT INSERT ANY PRINTING STATEMENTS LIKE echo,print etc because it will put the same data in Output Downloading file, and hence binary file(images,audio,video...) will be corrupted
// these are important statements
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename=' . $file_name);
    header('Content-Transfer-Encoding: binary');
// Important statements
    $file = fopen($file_path, 'rb');
    if ($file) {
        fpassthru($file);
    }
} else {
    header("location:../login.php");
}
?>