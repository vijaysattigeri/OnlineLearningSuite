<?php
session_start();
include '../database_connect_parameters.inc';
if (isset($_SESSION['logged_in_user_name'])) {

    $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);

    if (!$con) {
        die('Could not connect: ' . mysql_error());
    }
    $stored_file_name = $_REQUEST['stored_file_name'];
    $qry = "select * from resource_house where stored_file_name='$stored_file_name'";  // get the recent uploads first
    $result = mysqli_query($con, $qry);

    $out_res = "<table class='table table-striped'>";
    $actual_file_name = "";
    while ($row = mysqli_fetch_array($result)) {
        $actual_file_name = $row['file_name'];
        $dt = $row['upload_date'];
        $dt_javascript_str = "<script type='text/javascript'> var dtjs = new Date('$dt'); document.write(dtjs.toDateString()); document.write(' at '+dtjs.toLocaleTimeString()); </script>"; // Converting date to MORE READABLE form by using javascript
        $out_res .= "<tr><th align='left'>Name<td> </td> </th><td>" . htmlentities($row['file_name'], ENT_QUOTES) . "</td></tr><tr>";
        $out_res .= "<tr><th align='left'>Type<td> </td> </th><td>" . htmlentities($row['file_type'], ENT_QUOTES) . "</td></tr>";
        $out_res .= "<tr><th align='left'>Uploader<td> </td> </th><td>" . htmlentities($row['user_name'], ENT_QUOTES) . "</td></tr>";
        $out_res .= "<tr><th align='left'>Upload date<td> </td> </th><td>$dt_javascript_str</td></tr>";
        $out_res .= "<tr><th align='left'>Size(in Bytes)<td> </td></th><td>" . $row['file_size'] . "</td></tr>";
        $out_res .= "<tr><th align='left'>Downloads<td> </td> </th><td>" . $row['download_count'] . "</td></tr>";
        $out_res .= "<tr><th align='left'>Description<td> </td> </th><td>" . htmlentities($row['description'], ENT_QUOTES) . "</td></tr>";
    }
    $out_res .= "</table><br/>";
    mysqli_close($con);
    ?>

    <html>
        <head>
            <title> Resource -<?php echo htmlentities($actual_file_name, ENT_QUOTES); ?></title>
            <script src="../libraries/jquery-3.1.1.min.js"></script>
            <script src="../libraries/smooth_scroll/jquery.easing.min.js"></script>
            <script src="../libraries/smooth_scroll/scrolling-nav.js"></script>
            <link href="../libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
            <link href="../libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
            <script src="../libraries/bootstrap/js/bootstrap.js"></script>
            <link href="../smooth_scroll/scrolling-nav.css" rel="stylesheet" />
        </head>

        <body style="padding-top:100px; padding-bottom: 100px; background-image:url(../OLS_Images/tutorial_section.jpg); background-size:100%;background-attachment:fixed;"> 

            <div id="top_nav_bar_vj">
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="container-fluid" style="background-color:<?php
                    if ($_SESSION['logged_in_user_account_type'] == 2) {
                        echo "#4caf50";
                    } else {
                        echo "#c84747";
                    }
                    ?>;font-variant-caps:all-petite-caps;">
                        <!--This gives enough padding for navbar elements-->
                        <div class="navbar-header" style="color:#ffffff;">
                            <button type="button" class="navbar-toggle" data-target="#resize_menu_vj_top" data-toggle="collapse">
                                <!-- To get THREE bars(Icon bars) when we resize the window to smaller size-->
                                <span class="glyphicon glyphicon-menu-hamburger"></span>
                                <span>Menu</span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse" id="resize_menu_vj_top">
                            <ul class="nav navbar-nav">
                                <li id="list_id_index"><a href="../index.php"><img src="../OLS_Images/home.jpg" width="50" height="50" style="border-radius:2px 18px" /><span style="color:#ffffff; font:initial; font-style:italic; font-size:xx-large;">&nbsp; Online Learning Suite</span></a></li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">                              
                                <li id="list_id_profile"><a href="../user_profile.php?user_name=<?php echo $_SESSION['logged_in_user_name']; ?>" target="_blank"><img src="../profile_pics/<?php echo $_SESSION['logged_in_user_profile_pic_name']; ?>" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; PROFILE</span></a></li>
                                <li id="list_id_upload_file"><a href="upload_dialog.php"><img src="../OLS_Images/upload.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; UPLOAD A FILE</span></a></li>
                                <li id="list_id_delete_file"><a href="self_resource_delete_ui.php"><img src="../OLS_Images/delete.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; DELETE YOUR FILES</span></a></li>                                
                                <li id="list_id_logout"><a href="../logout.php"><img src="../OLS_Images/logout.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; LOGOUT</span></a></li>                                 
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>


            <div class="container" style="background-color:#f2f2f2; border: 1px solid #080808; border-radius: 5px;box-shadow: 0 1px 70px rgb(0, 0, 0);">
                <form action="download_dialog.php"> <?php echo $out_res; ?>               
                    <center> <button name="stored_file_name" value="<?php echo $stored_file_name; ?>" class="btn btn-success">Download </button></center>
                </form>
            </div>

        </body>
    </html>
    <?php
} else {
    header("location:../login.php");
}
?>