<?php

session_start();
include '../database_connect_parameters.inc';

if (isset($_SESSION['logged_in_user_name'])) {

    $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
    if (!$con) {
        die('Could not connect to database: ' . mysql_error());
        exit(14);
    }

    $user_id = $_SESSION['logged_in_user_id'];
    $stream = $_SESSION['logged_in_user_stream'];
    $qry = "DELETE FROM exam_student WHERE student_id ='$user_id' and stream='$stream'";
    $res = mysqli_query($con, $qry);
    if (!$res) {
        echo "<h2 style='color:red'>Deletion from <i>exam_student</i> table falied</h2>";
        exit(15);
    }
    header("location:questions_display.php");
    mysqli_close($con);
} else {
    header("location:../login.php");
}
?>