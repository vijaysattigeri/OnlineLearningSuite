<?php
session_start();
include '../database_connect_parameters.inc';
if (isset($_SESSION['logged_in_maintain_user'])) {
    ?>
    <html>
        <head>
            <title>Questions adding</title>
        </head>
        <body>
            <?php
            if (isset($_REQUEST['question_submit'])) {

                //Database connection
                $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
                if (!$con) {
                    die('Could not connect to database: ' . mysql_error());
                    exit(14);
                }

                //Extract posted data.
                $questions = $_REQUEST['questions'];
                $options = $_REQUEST['options'];
                $correct_option = $_REQUEST['correct_option'];
                $stream = $_REQUEST['stream'];

                //Array indexing parameter.
                $start_option_index = 0;
                $end_option_index = $start_option_index + 3;
                $ans_index = 0;
                $op1 = "";
                $op2 = "";
                $op3 = "";
                $op4 = "";
                $option_array; // To store 4 options
                //Extract data
                foreach ($questions as $q) {

                    $j = 0; //Options array index
                    for ($i = $start_option_index; $i <= $end_option_index; $i++) {
                        $option_array[$j++] = mysqli_real_escape_string($con, $options[$i]);
                    }
                    $answer = $correct_option[$ans_index];
                    $start_option_index += 4;
                    $end_option_index = $start_option_index + 3;
                    $ans_index++;
                    $j = 0;

                    // Database insertion
                    $q = mysqli_real_escape_string($con, $q);
                    $qry = "INSERT INTO `exam_question_paper` (`q_id`, `question`, `option1`, `option2`, `option3`, `option4`, `answer`, `stream`) VALUES (NULL, '$q', '$option_array[0]', '$option_array[1]', '$option_array[2]', '$option_array[3]', '$answer', '$stream')";
                    if (mysqli_query($con, $qry)) {
                        echo"<h1 style='color:green'>Insertion successful</h1>";
                    } else {
                        echo"<h1 style='color:red'>Insertion failed. Issue : </h1>" . mysqli_error($con);
                        exit(12);
                    }
                }
                mysqli_close($con);
                header("location:maintain_exam.php");
            } else {
                header("Location:add_questions_ui.php");
            }
            ?>
        </body>
    </html>
    <?php
} else {
    header("location:../login.php");
}
?>