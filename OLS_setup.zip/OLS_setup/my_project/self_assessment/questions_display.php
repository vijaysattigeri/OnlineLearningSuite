<?php
session_start();
include '../database_connect_parameters.inc';
if (isset($_SESSION['logged_in_user_name'])) {
    ?>

    <html>
        <head>
            <title>Question display</title>
            <script src="../libraries/jquery-3.1.1.min.js"></script>
            <script src="../libraries/smooth_scroll/jquery.easing.min.js"></script>
            <script src="../libraries/smooth_scroll/scrolling-nav.js"></script>
            <link href="../libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
            <link href="../libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
            <script src="../libraries/bootstrap/js/bootstrap.js"></script>
            <link href="../smooth_scroll/scrolling-nav.css" rel="stylesheet" />           
        </head>
        <body style="padding-top:100px; padding-bottom: 100px; background-image:url(../OLS_Images/tutorial_section.jpg); background-size:100%;background-attachment:fixed;"> 

            <div id="top_nav_bar_vj">
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="container-fluid" style="background-color:<?php
                    if ($_SESSION['logged_in_user_account_type'] == 2) {
                        echo "#4caf50";
                    } else {
                        echo "#c84747";
                    }
                    ?>;font-variant-caps:all-petite-caps;">
                        <!--This gives enough padding for navbar elements-->
                        <div class="navbar-header" style="color:#ffffff;">
                            <button type="button" class="navbar-toggle" data-target="#resize_menu_vj_top" data-toggle="collapse">
                                <!-- To get THREE bars(Icon bars) when we resize the window to smaller size-->
                                <span class="glyphicon glyphicon-menu-hamburger"></span>
                                <span>Menu</span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse" id="resize_menu_vj_top">
                            <ul class="nav navbar-nav">
                                <li id="list_id_index"><a href="../index.php"><img src="../OLS_Images/home.jpg" width="50" height="50" style="border-radius:2px 18px" /><span style="color:#ffffff; font:initial; font-style:italic; font-size:xx-large;">&nbsp; Online Learning Suite</span></a></li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">                              
                                <li id="list_id_profile"><a href="../user_profile.php?user_name=<?php echo $_SESSION['logged_in_user_name']; ?>" target="_blank"><img src="../profile_pics/<?php echo $_SESSION['logged_in_user_profile_pic_name']; ?>" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; PROFILE</span></a></li>
                                <li id="list_id_logout"><a href="../logout.php"><img src="../OLS_Images/logout.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; LOGOUT</span></a></li>                                 
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>

            <?php
            //Database connection
            $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
            if (!$con) {
                die('Could not connect to database: ' . mysql_error());
                exit(14);
            }

            //Extract form data
            $stream = $_SESSION['logged_in_user_stream'];

            $user_name = $_SESSION['logged_in_user_name'];
            $user_id = $_SESSION['logged_in_user_id'];

            $attempted_q_id;
            $i = 0;
            $all_q_id;
            $not_attempted_q_id;
            $stud_empty_flag = 1;
            $question_empty_flag = 1;

            //Find question_id's of attempted questions. 
            $qry2 = "select q_id from exam_student where student_id='$user_id' and stream='$stream'"; // stream is added becasuse to allow the user to try the questions from other stream also
            $res2 = mysqli_query($con, $qry2);
            while ($row = mysqli_fetch_array($res2)) {
                $attempted_q_id[$i] = $row['q_id'];
                $i++;
                $stud_empty_flag = 0;
            }

            //Find question_id's of all questions
            $qry3 = "select q_id from exam_question_paper where stream='$stream'";
            $res3 = mysqli_query($con, $qry3);
            $i = 0;
            while ($row = mysqli_fetch_array($res3)) {
                $all_q_id[$i] = $row['q_id'];
                $i++;
                $question_empty_flag = 0;
            }
            if (empty($all_q_id) || $question_empty_flag == 1) {
                ?>
                <div class="container" style="padding:50px 50px 50px 50px; text-align:center; background-color:white;border-radius:20px 20px; box-shadow:0 1px 60px <?php
                if ($_SESSION['logged_in_user_account_type'] == 2) {
                    echo "rgb(76, 175, 80)";
                } else {
                    echo "rgb(200, 71, 71)";
                }
                ?>;"><h2 style='color:red'>No questions available</h2><a href='index.php' class="btn btn-success">Exam Home</a></div></body></html>";
                     <?php
                     exit(1);
                 } else {

                     //However checking array for emptiness works but still for extra accuracy and perfectness $empty_flag is being used 
                     if (empty($attempted_q_id) || $stud_empty_flag == 1) {
                         ?>
            <div class="container">
                <div class="row">

                    <div class="col-md-1">
                    </div>

                    <div class="col-md-10" style="padding:50px 50px 50px 50px; background-color:white;border-radius:20px 20px; box-shadow:0 1px 60px <?php
                    if ($_SESSION['logged_in_user_account_type'] == 2) {
                        echo "rgb(76, 175, 80)";
                    } else {
                        echo "rgb(200, 71, 71)";
                    }
                    ?>;">
                        <div style="font:20px sans-serif">
                            <form action="evaluate.php" method="post">                                                                           
                                <ol>
                                    <?php
                                    $question_counter = 1;
                                    $question_option_name = array("q1", "q2", "q3", "q4", "q5", "q6", "q7", "q8", "q9", "q10", "q11");
                                    $qry4 = "SELECT q_id,question,option1,option2,option3,option4 from exam_question_paper where stream='$stream' limit 11;"; // To read only 11 items from database to give best performance instead of selecting all rows/records, hence limit 11 is used
                                    $res4 = mysqli_query($con, $qry4);
                                    while ($row = mysqli_fetch_array($res4)) {
                                        $name_q = $question_option_name[$question_counter - 1];
                                        $question_identifier = "question_id_" . $name_q; //To generate unique name for all inputs, string are being concatenated.
                                        echo "<li><b>" . htmlentities($row['question'], ENT_QUOTES) . "</b><input type='hidden' name='$question_identifier' value='" . $row['q_id'] . "' />"; // To associate options to a question.
                                        echo "<ul style='list-style:none'><li><input type='radio' name='$name_q' value='1' /><label>&nbsp;" . htmlentities($row['option1'], ENT_QUOTES) . "</label></li><li><input type='radio' name='$name_q' value='2' /><label>&nbsp;" . htmlentities($row['option2'], ENT_QUOTES) . "</label></li><li><input type='radio' name='$name_q' value='3' /><label>&nbsp;" . htmlentities($row['option3'], ENT_QUOTES) . "</label></li><li><input type='radio' name='$name_q' value='4' /><label>&nbsp;" . htmlentities($row['option4']) . "</label></li></li></ul></li>";
                                        if ($question_counter == 10) {
                                            break;
                                        }
                                        $question_counter++;
                                    }
                                    ?>

                                </ol>                                                                           
                                <input type="submit" value="SUBMIT" name="submit_answers" class="btn btn-success" />
                                <input type="reset" value="RESET" class="btn btn-warning" style="float:right;" />
                            </form>
                        </div>
                    </div>

                    <div class="col-md-1">
                    </div>

                </div>
            </div>
            <?php
        } else {
            //Displayes ONLY NON-attempted questions.

            for ($i = 0; $i < count($all_q_id); $i++) {
                foreach ($attempted_q_id as $att_que) {
                    if ($all_q_id[$i] == $att_que) {
                        $all_q_id[$i] = 0; // Make the attempted question_id as ZERO
                    }
                }
            }

            //get the question_id's those have not been attempted by user(NON-ZERO)
            $i = 0;
            $attempt_flag = 1; //To check whether the user attempted all QUESTIONS
            foreach ($all_q_id as $aqd) {
                if ($aqd != 0) {
                    $not_attempted_q_id[$i] = $aqd;
                    $i++;
                    $attempt_flag = 0;
                }
            }

            if (empty($not_attempted_q_id) || $attempt_flag == 1) {
                ?>
                <div class="container" style="text-align:center;padding:50px 50px 50px 50px; background-color:white;border-radius:20px 20px; box-shadow:0 1px 60px <?php
                if ($_SESSION['logged_in_user_account_type'] == 2) {
                    echo "rgb(76, 175, 80)";
                } else {
                    echo "rgb(200, 71, 71)";
                }
                ?>;">
                    <h2>No more NEW questions to try. Click on below link to solve the same questions once again.</h2>
                    <a href='solve_again.php' class="btn btn-success">SOLVE QUESTIONS AGAIN</a>
                </div>

                <?php
            } else {
                ?>

                <div class="container">
                    <div class="row">

                        <div class="col-md-1">
                        </div>

                        <div class="col-md-10" style="padding:50px 50px 50px 50px; background-color:white;border-radius:20px 20px; box-shadow:0 1px 60px <?php
                        if ($_SESSION['logged_in_user_account_type'] == 2) {
                            echo "rgb(76, 175, 80)";
                        } else {
                            echo "rgb(200, 71, 71)";
                        }
                        ?>;">
                            <div style="font:20px sans-serif">
                                <form action="evaluate.php" method="post">                                                                                     
                                    <ol>
                                        <?php
                                        $question_counter = 1;
                                        $question_option_name = array("q1", "q2", "q3", "q4", "q5", "q6", "q7", "q8", "q9", "q10", "q11");
                                        foreach ($not_attempted_q_id as $current_id) {
                                            $qry5 = "SELECT q_id,question,option1,option2,option3,option4 from exam_question_paper where q_id='$current_id';";
                                            $res5 = mysqli_query($con, $qry5);
                                            $name_q = $question_option_name[$question_counter - 1];
                                            while ($row = mysqli_fetch_array($res5)) {
                                                $question_identifier = "question_id_" . $name_q; //To generate unique name for all inputs, string are being concatenated.
                                                echo "<li><b>" . htmlentities($row['question'], ENT_QUOTES) . "</b><input type='hidden' name='$question_identifier' value='" . $row['q_id'] . "' />"; // To associate options to a question.
                                                echo "<ul style='list-style:none'><li><input type='radio' name='$name_q' value='1' /><label>&nbsp;" . htmlentities($row['option1'], ENT_QUOTES) . "</label></li><li><input type='radio' name='$name_q' value='2' /><label>&nbsp;" . htmlentities($row['option2'], ENT_QUOTES) . "</label></li><li><input type='radio' name='$name_q' value='3' /><label>&nbsp;" . htmlentities($row['option3'], ENT_QUOTES) . "</label></li><li><input type='radio' name='$name_q' value='4' /><label>&nbsp;" . htmlentities($row['option4']) . "</label></li></li></ul></li>";
                                            }
                                            if ($question_counter == 10) {
                                                break; // Only 10 questions should be displayed
                                            }
                                            $question_counter++;
                                        }
                                        ?>

                                    </ol>                                            
                                    <input type="submit" value="SUBMIT" name="submit_answers" class="btn btn-success" />
                                    <input type="reset" value="RESET" class="btn btn-warning" style="float:right;" />
                                </form>
                            </div>
                        </div>

                        <div class="col-md-1">
                        </div>

                    </div>
                </div>
                <?php
            }
        }
    }
    mysqli_close($con);
    ?>
    </body>
    </html>

    <?php
} else {
    header("location:../login.php");
}
?>