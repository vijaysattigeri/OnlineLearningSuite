<?php
session_start();
include '../database_connect_parameters.inc';
if (isset($_SESSION['logged_in_maintain_user'])) {
    ?>
    <html>
        <head>
            <title>Remove prev. set</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <script src="../libraries/jquery-3.1.1.min.js"></script>
            <script src="../libraries/smooth_scroll/jquery.easing.min.js"></script>
            <script src="../libraries/smooth_scroll/scrolling-nav.js"></script>
            <link href="../libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
            <link href="../libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
            <script src="../libraries/bootstrap/js/bootstrap.js"></script>
            <link href="../smooth_scroll/scrolling-nav.css" rel="stylesheet" />   
        </head> <!-- This part is written outside because to apply the bootstrap and other libraries to WHOLE document-->
        <body style="padding-top:140px; background-image:url(../OLS_Images/maintain_bg.jpg); background-size:100%;background-attachment:fixed;">
            <!--Style By Vijay-->

            <div id="top_nav_bar_vj">
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="container-fluid" style="background-color:#0080ff;font-variant-caps:all-petite-caps;">
                        <!--This gives enough padding for navbar elements-->
                        <div class="navbar-header" style="color:#ffffff;">
                            <button type="button" class="navbar-toggle" data-target="#resize_menu_vj_top" data-toggle="collapse">
                                <!-- To get THREE bars(Icon bars) when we resize the window to smaller size-->
                                <span class="glyphicon glyphicon-menu-hamburger"></span>
                                <span>Menu</span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse" id="resize_menu_vj_top">
                            <ul class="nav navbar-nav">
                                <li id="list_id_index"><a class="page-scroll" href="../maintenance_team.php"><img src="../OLS_Images/settings.jpg" width="50" height="50" style="border-radius:2px 18px" /><span style="color:#ffffff; font:initial; font-style:italic; font-size:xx-large;">&nbsp; OLS Maintenance home</span></a></li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">                                
                                <li id="list_id_logout"><a href="../logout.php"><img src="../OLS_Images/logout.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; LOGOUT</span></a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
            <div class="container" style="padding:150px 150px 150px 150px; text-align: center; background-color:white;border-radius:20px 20px; box-shadow:0 1px 100px rgb(200, 71, 71);">


                <?php
                if (isset($_REQUEST['stream_submit'])) {

                    $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
                    if (!$con) {
                        die('Could not connect to database: ' . mysql_error());
                        exit(14);
                    }
                    $stream = $_REQUEST['stream'];

                    $qry_rows = "SELECT COUNT(*) FROM exam_question_paper where stream='$stream';";
                    $res_rows = mysqli_query($con, $qry_rows); // Only if there exist previous questions
                    $tmp = mysqli_fetch_array($res_rows);
                    $no_of_rows = $tmp[0];

                    if ($no_of_rows > 0) {

                        //Creating previous questions report in HTML format. these reports are stored in "previous_question_set" folder

                        date_default_timezone_set("Asia/Kolkata"); // Set INDIA's timezone
                        $date_created = date('Y-m-d H:i:s');
                        $arr_date = date_parse($date_created);
                        $y = $arr_date['year'];
                        $m = $arr_date['month'];
                        $d = $arr_date['day'];
                        $h = $arr_date['hour'];
                        $min = $arr_date['minute'];
                        $s = $arr_date['second'];
                        $question_counter = 0;

                        $date_javascript_str = "<script type='text/javascript'> var dtjs = new Date('$date_created'); document.write(dtjs.toDateString()); document.write(' at '+dtjs.toLocaleTimeString()); </script>"; // Converting date to MORE READABLE form by using javascript

                        $report_string = "<!DOCTYPE html><html><head><title>Prev_que_set</title><meta charset='utf-8' /></head><body><h1 style='text-align:center'>Generated on $date_javascript_str </h1>";
                        $report_string .= "<table align='center' border='1' cellpadding='14' cellspacing='0'><tr><th>Q.No.</th><th>Question</th><th>Option1</th><th>Option2</th><th>Option3</th><th>Option4</th><th>Correct answer</th></tr>";

                        $qry1 = "select * from exam_question_paper WHERE stream='$stream'";
                        $res1 = mysqli_query($con, $qry1);
                        while ($row = mysqli_fetch_array($res1)) {
                            $question_counter++;
                            $str_option = "";
                            switch ($row['answer']) {
                                case 1: $str_option = "option1";
                                    break;
                                case 2: $str_option = "option2";
                                    break;
                                case 3: $str_option = "option3";
                                    break;
                                case 4: $str_option = "option4";
                                    break;
                                default : $str_option = "option1";
                                    break;
                            }
                            $answer = htmlentities($row[$str_option], ENT_QUOTES);
                            $report_string .= "<tr><td>$question_counter</td><td>" . htmlentities($row['question'], ENT_QUOTES) . "</td><td>" . htmlentities($row['option1'], ENT_QUOTES) . "</td><td>" . htmlentities($row['option2'], ENT_QUOTES) . "</td><td>" . htmlentities($row['option3'], ENT_QUOTES) . "</td><td>" . htmlentities($row['option4'], ENT_QUOTES) . "</td><td>" . $answer . "</td></tr>";
                        }
                        $report_string .= "</table></body></html>";

                        // create file and load data
                        $file_name = "prev_que_set_" . $d . "_" . $m . "_" . $y . "_time_" . $h . "_" . $min . "_" . $s . ".html";
                        $file_pointer = fopen("previous_question_set/" . $file_name, "w");
                        if ($file_pointer == false) {
                            echo"File creation failed...!!!! :-( ";
                            exit(15);
                        }
                        $file_genartion = fwrite($file_pointer, $report_string);
                        fclose($file_pointer);

                        $qry2 = "INSERT INTO `previous_question_set` (`file_name`, `create_date`, `stream`) VALUES ('$file_name', '$date_created', '$stream');";
                        $res2 = mysqli_query($con, $qry2);

                        // Delete from exam_student table first, because it has a foreign key            
                        $qry3 = "DELETE FROM exam_student WHERE stream='$stream'";
                        $res3 = mysqli_query($con, $qry3);

                        //Delete actual questions 
                        $qry4 = "DELETE FROM exam_question_paper WHERE stream='$stream'";
                        $res4 = mysqli_query($con, $qry4);
                        if (!$res2 || !$res2 || !$res3 || !$res4) {
                            echo "<h3 style=color:red>Operation falied... Error encountered." . mysqli_error($con) . "</h3>";
                        }
                    } else {
                        echo "<h3 style=color:red>No previous questions found....</h3><br/><a href='maintain_exam.php' class='btn btn-primary'>Exam monitor home</a>";
                        exit(3);
                    }

                    mysqli_close($con);
                    header("location:maintain_exam.php");
                } else {
                    ?>
                    <script type="text/javascript"> //script written inside the body
                        function validate()
                        {
                            var dom = document.getElementById('stream_id').value;
                            if (dom == 0)
                            {
                                alert("SELECT THE STREAM...");
                                return false;
                            } else
                            {
                                return(confirm("Sure, want to REMOVE previous set ?"));
                            }
                        }
                    </script> 



                    <form action="<?php $PHP_SELF ?>" method="post" onsubmit="return validate();">
                        <table class="table">
                            <tr>
                                <td>
                                    <h4>Select stream</h4>
                                </td>
                                <td>
                                    <select id="stream_id" name="stream" class="form-control">
                                        <option value='0'>Select Stream</option>
                                        <option value='1'>Computer science</option>
                                        <option value='2'>Information science</option>
                                        <option value='3'>Civil Engg</option>
                                        <option value='4'>Mechanical engg</option>
                                        <option value='5'>Electronics</option>
                                        <option value='6'>Other</option>
                                    </select>
                                </td>
                                <td>
                                    <input type="submit" name="stream_submit" value="SUBMIT" class="btn btn-primary" /> 
                                </td>
                            </tr>
                        </table>
                    </form>

                    <?php
                }
                ?>
            </div>

        </body>
    </html>
    <?php
} else {
    header("location:../login.php");
}
?>