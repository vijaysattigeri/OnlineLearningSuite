<?php
session_start();
include '../database_connect_parameters.inc';
if (isset($_SESSION['logged_in_user_name'])) {
    ?>
    <!DOCTYPE html>
    <html>
        <head>
            <title>Test Result</title>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <script src="../libraries/jquery-3.1.1.min.js"></script>
            <script src="../libraries/smooth_scroll/jquery.easing.min.js"></script>
            <script src="../libraries/smooth_scroll/scrolling-nav.js"></script>
            <link href="../libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
            <link href="../libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
            <script src="../libraries/bootstrap/js/bootstrap.js"></script>
            <link href="../smooth_scroll/scrolling-nav.css" rel="stylesheet" />      
        </head>

        <body style="padding-top:100px; padding-bottom: 100px; background-image:url(../OLS_Images/tutorial_section.jpg); background-size:100%;background-attachment:fixed;"> 

            <div id="top_nav_bar_vj">
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="container-fluid" style="background-color:<?php
                    if ($_SESSION['logged_in_user_account_type'] == 2) {
                        echo "#4caf50";
                    } else {
                        echo "#c84747";
                    }
                    ?>;font-variant-caps:all-petite-caps;">
                        <!--This gives enough padding for navbar elements-->
                        <div class="navbar-header" style="color:#ffffff;">
                            <button type="button" class="navbar-toggle" data-target="#resize_menu_vj_top" data-toggle="collapse">
                                <!-- To get THREE bars(Icon bars) when we resize the window to smaller size-->
                                <span class="glyphicon glyphicon-menu-hamburger"></span>
                                <span>Menu</span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse" id="resize_menu_vj_top">
                            <ul class="nav navbar-nav">
                                <li id="list_id_index"><a href="../index.php"><img src="../OLS_Images/home.jpg" width="50" height="50" style="border-radius:2px 18px" /><span style="color:#ffffff; font:initial; font-style:italic; font-size:xx-large;">&nbsp; Online Learning Suite</span></a></li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">                              
                                <li id="list_id_profile"><a href="../user_profile.php?user_name=<?php echo $_SESSION['logged_in_user_name']; ?>" target="_blank"><img src="../profile_pics/<?php echo $_SESSION['logged_in_user_profile_pic_name']; ?>" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; PROFILE</span></a></li>
                                <li id="list_id_logout"><a href="../logout.php"><img src="../OLS_Images/logout.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; LOGOUT</span></a></li>                                 
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>

            <div class="container">
                <div class="row">
                    <div class="col-md-1" style="text-align:center">
                    </div>
                    <div class="col-md-10" style="padding:30px 30px 30px 30px;background-color:white;border-radius:20px 20px; box-shadow:0 1px 20px <?php
                    if ($_SESSION['logged_in_user_account_type'] == 2) {
                        echo "rgb(76, 175, 80)";
                    } else {
                        echo "rgb(200, 71, 71)";
                    }
                    ?>;">       
                         <?php
                         if (isset($_REQUEST['submit_answers'])) {
                             //Database connection
                             $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
                             if (!$con) {
                                 die('Could not connect to database: ' . mysql_error());
                                 exit(14);
                             }
                             $user_name = $_SESSION['logged_in_user_name'];
                             $user_id = $_SESSION['logged_in_user_id'];
                             $stream = $_SESSION['logged_in_user_stream'];
                             $question_option_name = array("q1", "q2", "q3", "q4", "q5", "q6", "q7", "q8", "q9", "q10", "q11");
                             $correct_count = 0;

                             $output_result = "<div id='result_table' style='padding:25px 25px 25px 25px;font:20px sans-serif'><h2 style='text-align:center'>Your result is as follows</h2><br/><table class='table table-bordered'><tr><th> QUESTION </th><th> YOUR ANSWER </th><th> CREDIT </th><th> CORRECT ANSWER </th></tr>";


                             foreach ($question_option_name as $opt_name) {
                                 if (isset($_REQUEST[$opt_name])) {
                                     $que_id_name = "question_id_" . $opt_name;
                                     $q_id_form = $_REQUEST[$que_id_name]; //Obtaining hidden field values to check the answer by accessing via question-id obtained here.
                                     $option_selected = $_REQUEST[$opt_name];
                                     $question = "";
                                     $your_answer = "";
                                     $credit_img = "";
                                     $corrcet_answer = "";
                                     $bootstrap_row_color = "";
                                     $option_str = "";
                                     switch ($option_selected) {
                                         case 1:$option_str = "option1";
                                             break;
                                         case 2:$option_str = "option2";
                                             break;
                                         case 3:$option_str = "option3";
                                             break;
                                         case 4:$option_str = "option4";
                                             break;
                                         default :$option_str = "option1";
                                             break;
                                     }

                                     $qry1 = "SELECT * FROM `exam_question_paper` where q_id='$q_id_form'";
                                     $res1 = mysqli_query($con, $qry1);
                                     while ($row = mysqli_fetch_array($res1)) {
                                         $question = htmlentities($row['question'], ENT_QUOTES);
                                         $your_answer = htmlentities($row[$option_str], ENT_QUOTES);
                                         $ans_str = "";
                                         switch ($row['answer']) {
                                             case 1:$ans_str = "option1";
                                                 break;
                                             case 2:$ans_str = "option2";
                                                 break;
                                             case 3:$ans_str = "option3";
                                                 break;
                                             case 4:$ans_str = "option4";
                                                 break;
                                             default :$ans_str = "option1";
                                                 break;
                                         }
                                         $corrcet_answer = htmlentities($row[$ans_str], ENT_QUOTES);
                                         if ($row['answer'] == $option_selected) {
                                             $bootstrap_row_color = "success";
                                             $correct_count++;
                                             $credit_img = "../file_icons/correct_image.png";
                                         } else {
                                             $bootstrap_row_color = "danger";
                                             $credit_img = "../file_icons/wrong_image.png";
                                         }
                                     }
                                     $output_result .= "<tr class='$bootstrap_row_color'><td> $question </td><td> $your_answer </td><td><img src='$credit_img' width='30' height='30' /></td><td>$corrcet_answer</td></tr>";

                                     //Entry in exam_student table
                                     $qry2 = "INSERT INTO `exam_student` (`q_id`, `student_id`,`stream`) VALUES ('$q_id_form', '$user_id', '$stream');";
                                     $res2 = mysqli_query($con, $qry2);
                                     if (!$res2) {
                                         echo "<h1 style='color:red;'>Something went wrong in <i>exam_student</i> table</h1><br/><h2><a href='index.php'>Back to self-assessment home</a></h2>";
                                         exit(15);
                                     }
                                 }
                             }
                             // To color the score based on rank
                             $score_color = "#000000";
                             if ($correct_count < 4) {
                                 $score_color = "#ff0000";
                             } else if ($correct_count > 6) {
                                 $score_color = "#008000";
                             } else {
                                 $score_color = "#ff8000";
                             }
                             $output_result .= "<tr><td align='center' colspan='4'><h1 style='color:$score_color;'>Your score is : $correct_count </h1></td></tr></table> <a href='questions_display.php' class='btn btn-success'>Continue Exam</a><a href='index.php' class='btn btn-danger' style='float:right;'>Exam Home</a></div>";
                             echo $output_result;

                             mysqli_close($con);
                         } else {
                             header("location:index.php");
                         }
                         ?>
                    </div>
                    <div class="col-md-1" style="text-align:center">
                    </div>
                </div>
            </div>        
        </body>
    </html>
    <?php
} else {
    header("location:../login.php");
}
?>