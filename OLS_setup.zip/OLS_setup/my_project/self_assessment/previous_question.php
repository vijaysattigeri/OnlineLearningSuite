<?php
session_start();
include '../database_connect_parameters.inc';
if (isset($_SESSION['logged_in_user_name'])) {
    ?>
    <!DOCTYPE html>
    <html>
        <head>
            <title>Previous questions</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <script src="../libraries/jquery-3.1.1.min.js"></script>
            <script src="../libraries/smooth_scroll/jquery.easing.min.js"></script>
            <script src="../libraries/smooth_scroll/scrolling-nav.js"></script>
            <link href="../libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
            <link href="../libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
            <script src="../libraries/bootstrap/js/bootstrap.js"></script>
            <link href="../smooth_scroll/scrolling-nav.css" rel="stylesheet" />   
        </head>

        <body style="padding-top:100px; padding-bottom: 100px; background-image:url(../OLS_Images/tutorial_section.jpg); background-size:100%;background-attachment:fixed;"> 

            <div id="top_nav_bar_vj">
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="container-fluid" style="background-color:<?php
                    if ($_SESSION['logged_in_user_account_type'] == 2) {
                        echo "#4caf50";
                    } else {
                        echo "#c84747";
                    }
                    ?>;font-variant-caps:all-petite-caps;">
                        <!--This gives enough padding for navbar elements-->
                        <div class="navbar-header" style="color:#ffffff;">
                            <button type="button" class="navbar-toggle" data-target="#resize_menu_vj_top" data-toggle="collapse">
                                <!-- To get THREE bars(Icon bars) when we resize the window to smaller size-->
                                <span class="glyphicon glyphicon-menu-hamburger"></span>
                                <span>Menu</span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse" id="resize_menu_vj_top">
                            <ul class="nav navbar-nav">
                                <li id="list_id_index"><a href="../index.php"><img src="../OLS_Images/home.jpg" width="50" height="50" style="border-radius:2px 18px" /><span style="color:#ffffff; font:initial; font-style:italic; font-size:xx-large;">&nbsp; Online Learning Suite</span></a></li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">                              
                                <li id="list_id_profile"><a href="../user_profile.php?user_name=<?php echo $_SESSION['logged_in_user_name']; ?>" target="_blank"><img src="../profile_pics/<?php echo $_SESSION['logged_in_user_profile_pic_name']; ?>" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; PROFILE</span></a></li>
                                <li id="list_id_logout"><a href="../logout.php"><img src="../OLS_Images/logout.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; LOGOUT</span></a></li>                                 
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>

            <div class="container" style="padding:25px 25px 25px 25px; text-align:center;font:20px sans-serif; background-color:white;border-radius:20px 20px; box-shadow:0 1px 60px <?php
            if ($_SESSION['logged_in_user_account_type'] == 2) {
                echo "rgb(76, 175, 80)";
            } else {
                echo "rgb(200, 71, 71)";
            }
            ?>;">

                <?php
                $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
                if (!$con) {
                    die('Could not connect to database: ' . mysql_error());
                    exit(14);
                }
                $stream_str = "";
                $stream = $_SESSION['logged_in_user_stream'];
                switch ($stream) {
                    case 1: $stream_str = "Computer science";
                        break;
                    case 2: $stream_str = "Information science";
                        break;
                    case 3: $stream_str = "Civil Engg";
                        break;
                    case 4: $stream_str = "Mechanical engg";
                        break;
                    case 5: $stream_str = "Electronics";
                        break;
                    case 6: $stream_str = "Other";
                        break;
                    default :$stream_str = "Unknown";
                        break;
                }

                $qry_rows = "SELECT COUNT(*) FROM previous_question_set where stream='$stream';";
                $res_rows = mysqli_query($con, $qry_rows);
                $tmp = mysqli_fetch_array($res_rows);
                $no_of_rows = $tmp[0];

                if ($no_of_rows > 0) {

                    $serial_no = 0;
                    $output = "<div class='row'><div class='col-md-2' style='text-align:center'></div><div class='col-md-8' style='text-align:center'><h2 style='text-align:center'> $stream_str </h2><hr /><table class='table table-bordered' border='border' cellpadding='10'><tr><th>Sl. No.</th><th>Stream</th><th>Generated on</th><th>View file</th></tr>";

                    $qry = "select * from previous_question_set where stream='$stream';";
                    $res = mysqli_query($con, $qry);
                    while ($row = mysqli_fetch_array($res)) {
                        $serial_no++;
                        $dt = $row['create_date'];
                        $date_javascript_str = "<script type='text/javascript'> var dtjs = new Date('$dt'); document.write(dtjs.toDateString()); document.write(' at '+dtjs.toLocaleTimeString()); </script>"; // Converting date to MORE READABLE form by using javascript
                        $output .= "<tr><td> $serial_no </td><td>$stream_str</td><td>$date_javascript_str</td><td><a href='previous_question_set/" . $row['file_name'] . "' target='_blank'>Click to view file</a></td></tr>";
                    }
                    $output .= "</table></div><div class='col-md-2' style='text-align:center'></div></div><br />";
                    echo $output;
                } else {
                    echo "<h3 style='color:red; text-align:center;'>No entries found</h3>";
                }

                mysqli_close($con);
                ?>
                <br/>
                <br/>
                <a href="index.php" class="btn btn-success" style="text-align: center;">Self assessment home</a>              
            </div>
        </body>
    </html>

    <?php
} else {
    header("location:../login.php");
}
?>