<?php
session_start();
include '../database_connect_parameters.inc';
if (isset($_SESSION['logged_in_maintain_user'])) {
    ?>
    <!DOCTYPE html>
    <html>
        <head>
            <title>Add question</title>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <script src="../libraries/jquery-3.1.1.min.js"></script>
            <script src="../libraries/smooth_scroll/jquery.easing.min.js"></script>
            <script src="../libraries/smooth_scroll/scrolling-nav.js"></script>
            <link href="../libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
            <link href="../libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
            <script src="../libraries/bootstrap/js/bootstrap.js"></script>
            <link href="../smooth_scroll/scrolling-nav.css" rel="stylesheet" />           
            <script type="text/javascript">

                $(document).ready(function () {
                    $("#add_table_rows").click(function () {
                        $("table").append('<tr><td>Input question </td><td><textarea class="form-control" name="questions[]" cols="100" rows="5" placeholder="Enter the question here" required="required"></textarea></td></tr><tr><td> Option 1</td><td><textarea class="form-control" name="options[]" cols="50" rows="5" placeholder="Enter option 1 here" required="required"></textarea></td></tr><tr><td> Option 2</td><td><textarea class="form-control" name="options[]" cols="50" rows="5" placeholder="Enter option 2 here" required="required"></textarea></td></tr><tr><td> Option 3</td><td><textarea class="form-control" name="options[]" cols="50" rows="5" placeholder="Enter option 3 here" required="required"></textarea></td></tr><tr><td> Option 4</td><td><textarea class="form-control" name="options[]" cols="50" rows="5" placeholder="Enter option 4 here" required="required"></textarea></td></tr><tr><td> Correct option</td><td><select class="form-control" name="correct_option[]"><option value="0">Select option</option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option></select></td></tr>');
                    });
                });
            </script>
            <script type="text/javascript">
                function validate()
                {
                    var stream = document.getElementById('stream_id').value;
                    if (stream == 0)
                    {
                        alert("Choose the STREAM.....");
                        return false;
                    } else
                    {
                        return true;
                    }
                }
            </script>
        </head>


        <body style="padding-top:140px; background-image:url(../OLS_Images/maintain_bg.jpg); background-size:100%;background-attachment:fixed;">
            <!--Style By Vijay-->

            <div id="top_nav_bar_vj">
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="container-fluid" style="background-color:#0080ff;font-variant-caps:all-petite-caps;">
                        <!--This gives enough padding for navbar elements-->
                        <div class="navbar-header" style="color:#ffffff;">
                            <button type="button" class="navbar-toggle" data-target="#resize_menu_vj_top" data-toggle="collapse">
                                <!-- To get THREE bars(Icon bars) when we resize the window to smaller size-->
                                <span class="glyphicon glyphicon-menu-hamburger"></span>
                                <span>Menu</span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse" id="resize_menu_vj_top">
                            <ul class="nav navbar-nav">
                                <li id="list_id_index"><a class="page-scroll" href="../maintenance_team.php"><img src="../OLS_Images/settings.jpg" width="50" height="50" style="border-radius:2px 18px" /><span style="color:#ffffff; font:initial; font-style:italic; font-size:xx-large;">&nbsp; OLS Maintenance home</span></a></li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">                                
                                <li id="list_id_logout"><a href="../logout.php"><img src="../OLS_Images/logout.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; LOGOUT</span></a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>


            <div class="container" style="padding:50px 50px 50px 50px; background-color:white;border-radius:20px 20px; box-shadow:0 1px 100px rgb(200, 71, 71);">

                <form action="questions_add_script.php" method="post" onsubmit="return validate()">

                    <div class="row">
                        <div class="col-md-3">                            
                        </div>
                        <div class="col-md-3">
                            <h4>Select stream</h4>
                        </div>
                        <div class="col-md-3">
                            <select id="stream_id" name="stream" class="form-control">
                                <option value='0'>Select Stream</option>
                                <option value='1'>Computer science</option>
                                <option value='2'>Information science</option>
                                <option value='3'>Civil Engg</option>
                                <option value='4'>Mechanical engg</option>
                                <option value='5'>Electronics</option>
                                <option value='6'>Other</option>
                            </select>
                        </div>
                        <div class="col-md-3">                            
                        </div>
                    </div>

                    <br/>
                    <hr>
                    <!-- DO NOT insert a space or any other character/content in 'textarea' tag IF YOU DO SO, The place holder will be OVERWRITTEN by that space/character/content. CORRECT EXAMPLE IS : <textarea placeholder="enter text here"></textarea> -->
                    <table class="table" style="font: 20px sans-serif">
                        <tr>
                            <td>Input question </td>
                            <td><textarea class="form-control" name="questions[]" cols="100" rows="5" placeholder="Enter the question here" required="required"></textarea></td>
                        </tr>
                        <tr>
                            <td> Option 1</td>
                            <td><textarea class="form-control" name="options[]" cols="50" rows="5" placeholder="Enter option 1 here" required="required"></textarea></td>
                        </tr>
                        <tr>
                            <td> Option 2</td>
                            <td><textarea class="form-control" name="options[]" cols="50" rows="5" placeholder="Enter option 2 here" required="required"></textarea></td>
                        </tr>
                        <tr>
                            <td> Option 3</td>
                            <td><textarea class="form-control" name="options[]" cols="50" rows="5" placeholder="Enter option 3 here" required="required"></textarea></td>
                        </tr>
                        <tr>
                            <td> Option 4</td>
                            <td><textarea class="form-control" name="options[]" cols="50" rows="5" placeholder="Enter option 4 here" required="required"></textarea></td>
                        </tr>
                        <tr>
                            <td> Correct option</td>
                            <td><select class="form-control" name="correct_option[]"><option value="0">Select option</option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option></select></td>
                        </tr>
                    </table>
                    <div>
                        <input type="submit" value="submit" name="question_submit" class="btn btn-success" style="float:left" /></label>
                        <input type="reset" value="RESET" class="btn btn-warning" style="float:right" />
                    </div>
                </form>
                <center> 
                    <button id="add_table_rows" class="btn btn-primary">Add another question</button>
                </center>
            </div>
        </body>
    </html>

    <?php
} else {
    header("location:../login.php");
}
?>