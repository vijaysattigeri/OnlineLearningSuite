<?php
session_start();
include 'database_connect_parameters.inc';
if (isset($_SESSION['logged_in_user_name'])) {
    ?>
    <!DOCTYPE html>
    <html>
        <head>
            <title>OLS - Home</title>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <!-- First INCLUDE JQuery library later include/link bootstrap-->
            <script src="libraries/jquery-3.1.1.min.js"></script>
            <script src="libraries/smooth_scroll/jquery.easing.min.js"></script>
            <script src="libraries/smooth_scroll/scrolling-nav.js"></script>
            <link href="libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
            <link href="libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
            <script src="libraries/bootstrap/js/bootstrap.js"></script>
            <link href="smooth_scroll/scrolling-nav.css" rel="stylesheet" />
        </head>
        <body style="padding-top:80px; background-image:url(OLS_Images/home_background.jpg); background-size:100%;background-attachment:fixed;">
            <!--Style By Vijay-->
            <div id="top_nav_bar_vj">
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="container-fluid" style="background-color:<?php
                    if ($_SESSION['logged_in_user_account_type'] == 2) {
                        echo "#4caf50";
                    } else {
                        echo "#c84747";
                    }
                    ?>;font-variant-caps:all-petite-caps;">
                        <!--This gives enough padding for navbar elements-->
                        <div class="navbar-header" style="color:#ffffff;">
                            <button type="button" class="navbar-toggle" data-target="#resize_menu_vj_top" data-toggle="collapse">
                                <!-- To get THREE bars(Icon bars) when we resize the window to smaller size-->
                                <span class="glyphicon glyphicon-menu-hamburger"></span>
                                <span>Menu</span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse" id="resize_menu_vj_top">
                            <ul class="nav navbar-nav">
                                <li id="list_id_index"><a class="page-scroll" href="#actual_content_vj"><img src="OLS_Images/home.jpg" width="50" height="50" style="border-radius:2px 18px" /><span style="color:#ffffff; font:initial; font-style:italic; font-size:xx-large;">&nbsp; Online Learning Suite</span></a></li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">
                                <li id="list_id_services"><a class="page-scroll" href="#id_services"><img src="OLS_Images/services.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff">&nbsp; SERVICES</span></a></li>
                                <li id="list_id_profile"><a href="user_profile.php?user_name=<?php echo $_SESSION['logged_in_user_name']; ?>"><img src="profile_pics/<?php echo $_SESSION['logged_in_user_profile_pic_name']; ?>" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; PROFILE</span></a></li>
                                <li id="list_id_about"><a class="page-scroll" href="#id_about"><img src="OLS_Images/about.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; ABOUT</span></a></li>
                                <li id="list_id_logout"><a href="logout.php"><img src="OLS_Images/logout.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; LOGOUT</span></a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>

            <div id="actual_content_vj" class="container">
                <div id="desc_ols" style="color:white;padding-top:150px;">
                    <p style="padding:30px 30px 30px 30px; font:25px xx-large;text-align:justify;word-spacing:2px;">
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Education is the most important part of human life. Since its importance is realized the way of learning evolved through several changes. People want to learn the things in an easy and effective way. Among several ways of learning like theoretical learning, practical learning now a day online learning has become the trendy thing.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; OLS is a web application containing several interfaces to facilitate the learner to acquire the knowledge in an easy, effective and interesting way.
                    </p>
                </div>

                <div>
                    <!--Smooth scrolling is achieved by including "page-scroll" class from scrolling-nav.js, jquery.easing.min.js files-->
                    <p style="padding-top:200px; padding-bottom:200px; text-align:center;"><a class="btn <?php
                        if ($_SESSION['logged_in_user_account_type'] == 2) {
                            echo "btn-success";
                        } else {
                            echo "btn-danger";
                        }
                        ?> page-scroll" href="#id_services">SERVICES</a></p>
                </div>

                <div id="id_services" style="padding-top:100px;">

                    <div class="media" id="tutorial_section" style="background-color:white; border-radius:20px 20px; box-shadow:0 1px 20px <?php
                    if ($_SESSION['logged_in_user_account_type'] == 2) {
                        echo "rgb(76, 175, 80)";
                    } else {
                        echo "rgb(200, 71, 71)";
                    }
                    ?>;">
                        <div class="media-left media-middle">
                            <a href="tutorial_section/index.php">
                                <img src="OLS_Images/tutorial_section.jpg" width="420" height="380" alt="Tutorial_Section_Image" class="media-object" style="padding:10px 10px 10px 10px; border-radius:20px 20px;" />
                            </a>
                        </div>
                        <div class="media-body">
                            <h1 style="padding-left:5px;">
                                <a href="tutorial_section/index.php"> TUTORIAL SECTION </a>
                            </h1>
                            <p style="padding:30px 30px 30px 30px; font:25px xx-large;text-align:justify;word-spacing:2px;">
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; This is the place where exactly you start learning. This section provides you an interesting and easy interface to access the tutorials from OLS. Tutorials like video clips, images, text and audio clips posted by resource persons(teachers/lecturers/professors...) are viewed in an attractive and easy way. Along with the tutorials other related files are also attached in the form of 'Attachments' so that an user can view and download them.
                            </p>
                        </div>
                    </div>

                    <div class="media" id="resource_house" style="background-color:white;border-radius:20px 20px; box-shadow:0 1px 20px <?php
                    if ($_SESSION['logged_in_user_account_type'] == 2) {
                        echo "rgb(76, 175, 80)";
                    } else {
                        echo "rgb(200, 71, 71)";
                    }
                    ?>;">
                        <div class="media-body">
                            <h1 style="padding-left:50px;">
                                <a href="resource_house/index.php"> RESOURCE HOUSE</a>
                            </h1>
                            <p style="padding:30px 30px 30px 30px; font:25px xx-large;text-align:justify;word-spacing:2px;">
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  This section provides you an easy and efficient way to share the resources like study materials with other users. Resources may be documents(PDF,doc,docx,txt,pptx), video files(mpeg,avi,mkv), audio files(mp3,flac) and images(jpeg,gif,png). You can upload your file and also you can download the files that are uploded by other users. If you want you can delete the file you've uploaded. To avoid mis-use of this facility all files uploaded by users are validated by OLS Maintenance team. Maximum upload file size is 50MB.
                            </p>
                        </div>
                        <div class="media-left media-middle">
                            <a href="resource_house/index.php">
                                <img src="OLS_Images/resource_house.jpg" width="420" height="380" alt="Resource_House_Image" class="media-object" style="padding:10px 10px 10px 10px; border-radius:20px 20px;" />
                            </a>
                        </div>
                    </div>

                    <div class="media" id="self_assessment_exam" style="background-color:white; border-radius:20px 20px; box-shadow:0 1px 20px <?php
                    if ($_SESSION['logged_in_user_account_type'] == 2) {
                        echo "rgb(76, 175, 80)";
                    } else {
                        echo "rgb(200, 71, 71)";
                    }
                    ?>;">
                        <div class="media-left media-middle">
                            <a href="self_assessment/index.php">
                                <img src="OLS_Images/self_assessment.jpg" width="420" height="380" alt="Self_Assessment_Exam_Image" class="media-object" style="padding:10px 10px 10px 10px; border-radius:20px 20px;" />
                            </a>
                        </div>
                        <div class="media-body">
                            <h1 style="padding-left:5px;">
                                <a href="self_assessment/index.php"> SELF-ASSESSMENT ONLINE EXAM </a>
                            </h1>
                            <p style="padding:30px 30px 30px 30px; font:25px xx-large;text-align:justify;word-spacing:2px;">
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; This section provides a good way to selfassess the learnt thing from the tutorials. To accomplish this task an automated online exam is facilitated to the users. Each user is given a set of questions to be solved with 4 options for each question. Each time un-solved questions are displayed. Once the user complete solving all questions, he can choose to RESOLVE the same set of questions until next set of questions are updated by maintenance team. Previous question paper sets which are removed will be avilable for users to view and download.
                            </p>
                        </div>
                    </div>

                    <div class="media" id="discussion_forum" style="background-color:white;border-radius:20px 20px; box-shadow:0 1px 20px <?php
                    if ($_SESSION['logged_in_user_account_type'] == 2) {
                        echo "rgb(76, 175, 80)";
                    } else {
                        echo "rgb(200, 71, 71)";
                    }
                    ?>;">
                        <div class="media-body">
                            <h1 style="padding-left:50px;">
                                <a href="discussion_forum/index.php"> DISCUSSION FORUM</a>
                            </h1>
                            <p style="padding:30px 30px 30px 30px; font:25px xx-large;text-align:justify;word-spacing:2px;">
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Sometimes you may feel necessary to discusss on some stuff with your friends and other learners. This section provides an effective way to ask question and get several solutions by your friends and other users. you can also answer for other's questioins. If you want you can delete the questions you've asked and answers you've given to other's questions.
                            </p>
                        </div>
                        <div class="media-left media-middle">
                            <a href="discussion_forum/index.php">
                                <img src="OLS_Images/discussion_forum.jpg" width="420" height="380" alt="Resource_House_Image" class="media-object" style="padding:10px 10px 10px 10px; border-radius:20px 20px;" />
                            </a>
                        </div>
                    </div>

                </div>
            </div>

            <div class="container-fluid" style="padding:100px 100px 100px 100px">
                <div id="id_about" style="text-align:center; background-color:white; padding:25px 25px 25px 25px; border-radius:20px 20px; box-shadow:0 1px 20px <?php
                if ($_SESSION['logged_in_user_account_type'] == 2) {
                    echo "rgb(76, 175, 80)";
                } else {
                    echo "rgb(200, 71, 71)";
                }
                ?>;">
                    <h2> Developed by </h2>
                    <br />
                    <div class="row">
                        <div class="col-md-4">
                            <img src="OLS_Images/vijay.jpg" width="150" height="150" style="border-radius:150px 150px;" />
                            <p style="font:bold 20px verdana;"> Vijaymahantesh M. S.</p>
                            <p style="font:18px verdana; font-style:italic;">Core developer</p>
                        </div>
                        <div class="col-md-4">
                            <img src="OLS_Images/vijay.jpg" width="150" height="150" style="border-radius:150px 150px;" />
                            <p style="font:bold 20px verdana;"> Vadiraj M. H.</p>
                            <p style="font:18px verdana; font-style:italic;">Designer</p>
                        </div>
                        <div class="col-md-4">
                            <img src="OLS_Images/female.jpg" width="150" height="150" style="border-radius:150px 150px;" />
                            <p style="font:bold 20px verdana;"> Deepali P. K.</p>
                            <p style="font:18px verdana; font-style:italic;"> Software Tester</p>
                        </div>
                    </div>
                    <hr />
                    <h2> Guided by </h2>
                    <br />
                    <div class="row">
                        <div class="col-md-12">
                            <img src="OLS_Images/jyoti_mam.jpg" width="150" height="150" style="border-radius:150px 150px;" />
                            <p style="font:bold 20px verdana;"> Jyoti M. Hurakadli.</p>
                            <p style="font:18px verdana; font-style:italic;"> Associate Professor<br /> CSE department <br />BEC Bagalkot</p>
                        </div>
                    </div>
                </div>
            </div>

            <footer style="background-color:<?php
            if ($_SESSION['logged_in_user_account_type'] == 2) {
                echo "#4caf50";
            } else {
                echo "#c84747";
            }
            ?>;box-shadow:0 1px 20px rgb(0, 0, 0);">
                <div style="text-align:center;color:white;">
                    <h3>OLS 1.0</h3>
                    <h4>1st Release 30-may-2017</h4>
                    <h4>India</h4>
                </div>
            </footer>
        </body>
    </html>

    <?php
} else {
    header("location:login.php");
}
?>
