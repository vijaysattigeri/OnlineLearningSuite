<?php
session_start();
include '../database_connect_parameters.inc';
if (isset($_SESSION['logged_in_user_name'])) {

    if (isset($_REQUEST['forum_question_submit'])) {

        //Database connection
        $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
        if (!$con) {
            die('Could not connect to database: ' . mysql_error());
            exit(14);
        }
        date_default_timezone_set("Asia/Kolkata");
        $posted_date = date('Y-m-d H:i:s');
        $question = trim(mysqli_real_escape_string($con, $_REQUEST['forum_question_text']));

        $user_name = $_SESSION['logged_in_user_name'];
        $stream = $_SESSION['logged_in_user_stream'];
        $current_user_prof_pic_name = $_SESSION['logged_in_user_profile_pic_name'];

        if (!empty($question)) {

            $qry1 = "INSERT INTO `forum_questions` (`question`, `posted_date`, `posted_by`,`profile_pic_name`, `stream`) VALUES ('$question', '$posted_date', '$user_name','$current_user_prof_pic_name','$stream');";
            $res1 = mysqli_query($con, $qry1);

            if (!$res1) {
                echo "<h3 style='color:red'>Something went wrong while inserting your Question. ERROR : " . mysqli_error($con) . "</h3>";
                ?>
                <a href="index.php"> Discussion forum home </a>
                <br/>
                <a href="../index.php">OLS home </a>
                <?php
            } else {
                header("location:index.php");
            }
        } else {
            header("location:index.php");
        }
        mysqli_close($con);
    } else {
        header("location:index.php");
    }
} else {
    header("location:../login.php");
}
?>