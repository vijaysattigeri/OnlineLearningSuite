<?php

session_start();
include '../database_connect_parameters.inc';
if (isset($_SESSION['logged_in_maintain_user'])) {
    //Database connection
    $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
    if (!$con) {
        die('Could not connect to database: ' . mysql_error());
        exit(14);
    }

    //Questions and associated answers deletion.
    if (isset($_REQUEST['questions_id'])) {
        $questions_id = $_REQUEST['questions_id'];
        foreach ($questions_id as $q_id) {
            $qry1 = "DELETE FROM `forum_answers` WHERE `forum_answers`.`q_id_foreign` = '$q_id';";
            $res1 = mysqli_query($con, $qry1);
            if (!$res1) {
                echo "<h1 style='color:red'>Something went wrong while deleting from <i>forum_answers</i> table(Question/answer block)</h1>";
                echo mysqli_error($con);
                exit(1);
            }
            $qry2 = "DELETE FROM `forum_questions` WHERE `forum_questions`.`question_id` = $q_id";
            $res2 = mysqli_query($con, $qry2);
            if (!$res2) {
                echo "<h1 style='color:red'>Something went wrong while deleting from <i>forum_questions</i> table</h1>";
                echo mysqli_error($con);
                exit(2);
            }
        }
    }

    //Answers deletion.
    if (isset($_REQUEST['answers_id'])) {
        $answers_id = $_REQUEST['answers_id'];

        foreach ($answers_id as $ans_id) {
            $qry3 = "DELETE FROM `forum_answers` WHERE `forum_answers`.`answer_id` = '$ans_id';";
            $res3 = mysqli_query($con, $qry3);
            if (!$res3) {
                echo "<h1 style='color:red'>Something went wrong while deleting from <i>forum_answers</i> table(Only answers block)</h1>";
                echo mysqli_error($con);
                exit(3);
            }
        }
    }
    header("location:../maintenance_team.php");
} else {
    header("location:../login.php");
}
?>