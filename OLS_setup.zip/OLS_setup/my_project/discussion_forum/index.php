<?php
session_start();
include '../database_connect_parameters.inc';
if (isset($_SESSION['logged_in_user_name'])) {
    $user_name = $_SESSION['logged_in_user_name'];
    $current_user_prof_pic_name = $_SESSION['logged_in_user_profile_pic_name'];
    ?>
    <!DOCTYPE html>
    <html>
        <head>
            <title>OLS - Discussion home</title>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1">

            <!-- First INCLUDE JQuery library later include/link bootstrap-->
            <script src="../libraries/jquery-3.1.1.min.js"></script>
            <script src="../libraries/smooth_scroll/jquery.easing.min.js"></script>
            <script src="../libraries/smooth_scroll/scrolling-nav.js"></script>
            <link href="../libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
            <link href="../libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
            <script src="../libraries/bootstrap/js/bootstrap.js"></script>
            <link href="../smooth_scroll/scrolling-nav.css" rel="stylesheet" />

        </head>

        <body style="padding-top:100px; padding-bottom: 100px; background-image:url(../OLS_Images/tutorial_section.jpg); background-size:100%;background-attachment:fixed;"> 

            <!-- Navigation bar top-->   
            <div id="top_nav_bar_vj">
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="container-fluid" style="background-color:<?php
                    if ($_SESSION['logged_in_user_account_type'] == 2) {
                        echo "#4caf50";
                    } else {
                        echo "#c84747";
                    }
                    ?>;font-variant-caps:all-petite-caps;">
                        <!--This gives enough padding for navbar elements-->
                        <div class="navbar-header" style="color:#ffffff;">
                            <button type="button" class="navbar-toggle" data-target="#resize_menu_vj_top" data-toggle="collapse">
                                <!-- To get THREE bars(Icon bars) when we resize the window to smaller size-->
                                <span class="glyphicon glyphicon-menu-hamburger"></span>
                                <span>Menu</span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse" id="resize_menu_vj_top">
                            <ul class="nav navbar-nav">
                                <li id="list_id_index"><a href="../index.php"><img src="../OLS_Images/home.jpg" width="50" height="50" style="border-radius:2px 18px" /><span style="color:#ffffff; font:initial; font-style:italic; font-size:xx-large;">&nbsp; Online Learning Suite</span></a></li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">                              
                                <li id="list_id_profile"><a href="../user_profile.php?user_name=<?php echo $_SESSION['logged_in_user_name']; ?>" target="_blank"><img src="../profile_pics/<?php echo $_SESSION['logged_in_user_profile_pic_name']; ?>" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; PROFILE</span></a></li>                                
                                <li id="list_id_ask_que"><a href="ask_question.php"><img src="../OLS_Images/question.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; ASK A QUESTION </span></a></li>
                                <li id="list_id_delete_posts"><a href="user_delete.php"><img src="../OLS_Images/delete.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; DELETE YOUR POSTS </span></a></li>                               
                                <li id="list_id_logout"><a href="../logout.php"><img src="../OLS_Images/logout.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; LOGOUT</span></a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>

            <div id="actual_core_ontent">
                <?php
                //Database connection
                $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
                if (!$con) {
                    die('Could not connect to database: ' . mysql_error());
                    exit(14);
                }

                $stream = $_SESSION['logged_in_user_stream'];
                $qry1 = "SELECT * FROM `forum_questions` where stream='$stream' ORDER BY posted_date DESC";  // sort by last modified date
                $res1 = mysqli_query($con, $qry1);
                $empty_flag = TRUE;
                while ($row = mysqli_fetch_array($res1)) {
                    $empty_flag = FALSE;
                    $q_id_db = $row['question_id'];
                    $raw_date_que = $row['posted_date'];
                    $quest_prof_pic_name = $row['profile_pic_name'];
                    $que_str = htmlentities($row['question'], ENT_QUOTES);


                    $que_posted_date = "<script type='text/javascript'> var dtjs = new Date('$raw_date_que'); document.write(dtjs.toDateString()); document.write(' at '+dtjs.toLocaleTimeString()); </script>"; // Converting date to MORE READABLE form by using javascript
                    //Now display the question
                    ?>
                    <div class="container">
                        <div>
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h4></h4> <!-- for panel head height (By Vijay)-->
                                </div>

                                <div class="panel-body">

                                    <div class="row">
                                        <!-- Bootstrap grid system-->
                                        <div class="col-md-3 post-info">
                                            <dl style="border-right:5px solid #7a99b8;">
                                                <dt class="avatar text-left">
                                                    <img src="../profile_pics/<?php echo $quest_prof_pic_name; ?>" width="100" height="100" style="border-radius:100px 100px;" /> <!-- To make the profile picture cirle-->
                                                </dt>
                                                <dd class="text-left">
                                                    <a href="../display_profile_all_user.php?user_name=<?php echo $row['posted_by']; ?>" target="_blank"><?php echo $row['posted_by']; ?></a>
                                                </dd>
                                                <dd>
                                                    <hr>
                                                </dd>
                                                <dd><strong>Posted on :</strong> <?php echo $que_posted_date; ?></dd>
                                            </dl>
                                        </div>

                                        <div class="col-md-8">
                                            <div style="font:20px verdana;">
                                                <span style="font: bold 20px verdana;">Question : </span>
                                                <br/>
                                                <br/>
                                                <span>&nbsp;&nbsp;&nbsp; <?php echo $que_str; ?></span>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-footer">

                                    <div>
                                        <!-- By Vijay -->
                                        <form action="answer_question.php" method="post">
                                            <input type="hidden" name="question_id" value="<?php echo $q_id_db; ?>" />
                                            <input type="submit" class="btn-success" name="forum_answer" value="Answer this question" />
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php
                    $qry2 = "SELECT * FROM `forum_answers` where q_id_foreign='$q_id_db' ORDER BY posted_date DESC;";
                    $res2 = mysqli_query($con, $qry2);
                    while ($row2 = mysqli_fetch_array($res2)) {
                        $raw_date_ans = $row2['posted_date'];
                        $ans_posted_date = "<script type='text/javascript'> var dtjs = new Date('$raw_date_ans'); document.write(dtjs.toDateString()); document.write(' at '+dtjs.toLocaleTimeString()); </script>";
                        $ans_prof_pic_name = $row2['profile_pic_name'];
                        $ans_str = htmlentities($row2['answer'], ENT_QUOTES);
                        ?>
                        <div class="container" style="margin-right:14px;">
                            <div>

                                <div class="panel panel-primary">
                                    <div class="panel-heading" style="background-color:#595959; background-image:linear-gradient(to bottom, #595959 0%, #595959 100%);">
                                        <h5></h5> <!-- for panel head height (By Vijay)-->
                                    </div>

                                    <div class="panel-body">

                                        <div class="row">
                                            <!-- Bootstrap grid system-->
                                            <div class="col-md-3 post-info">
                                                <dl style="border-right:5px solid #7a99b8;">
                                                    <dt class="avatar text-left">
                                                        <img src="../profile_pics/<?php echo $ans_prof_pic_name; ?>" width="100" height="100" style="border-radius:100px 100px;" /> <!-- To make the profile picture cirle-->
                                                    </dt>
                                                    <dd class="text-left">
                                                        <a href="../display_profile_all_user.php?user_name=<?php echo $row2['posted_by']; ?>" target="_blank"><?php echo $row2['posted_by']; ?></a>
                                                    </dd>
                                                    <dd>
                                                        <hr>
                                                    </dd>
                                                    <dd><strong>Posted on : </strong> <?php echo $ans_posted_date; ?></dd>
                                                </dl>
                                            </div>

                                            <div class="col-md-8">
                                                <div style="font:20px verdana;">
                                                    <span style="font: bold 20px verdana;">Answer : </span>
                                                    <br />
                                                    <br/>
                                                    <span>&nbsp;&nbsp;&nbsp; <?php echo $ans_str; ?></span>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel-footer">
                                        <!--Just to make footer visible in the panel-->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                }
                if ($empty_flag == TRUE) {
                    ?>
                    <div class="container" style="padding:50px 50px 50px 50px; text-align: center;background-color:#ffffff; border-radius:10px; box-shadow:0 1px 60px <?php
                    if ($_SESSION['logged_in_user_account_type'] == 2) {
                        echo "rgb(76, 175, 80)";
                    } else {
                        echo "rgb(200, 71, 71)";
                    }
                    ?>;">
                        <h1 style='color:red;'>Sorry no discussions available.</h1>
                        <br/>
                        <br/>
                        <a href="../index.php" class="btn btn-success">OLS Home</a>
                    </div>
                    <?php
                }
                mysqli_close($con);
                ?>
            </div>  
        </body>
    </html>
    <?php
} else {
    header("location:../login.php");
}
?>