<?php
session_start();
require 'PHPMailer/PHPMailerAutoload.php';
include 'database_connect_parameters.inc';

if (isset($_SESSION['verification_required_user'])) {
    header("location:verification_page.php");
}
if (isset($_SESSION['logged_in_user_name'])) {
    header("location:index.php");
}

$user_exist_message = "";
if (isset($_REQUEST['register_submit'])) {

// Check for username existence and accordingly set the error-message.
    $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
    if (!$con) {
        die('Could not connect to database : ' . mysql_error());
    }
    $read_full_name = mysqli_real_escape_string($con, trim($_REQUEST['full_name']));
    $read_user_name = mysqli_real_escape_string($con, trim($_REQUEST['user_name']));
    $read_email_id = mysqli_real_escape_string($con, trim($_REQUEST['email_id']));
    $read_user_password_hash = md5($_REQUEST['user_password']);
    $read_stream = $_REQUEST['stream'];
    $read_account_type = $_REQUEST['account_type'];
    $read_sex = $_REQUEST['sex'];

    date_default_timezone_set("Asia/Kolkata");
    $account_created_date = date('Y-m-d H:i:s');
    $verification_code = rand(1000, 9999);

    $user_found = FALSE;

    $qry1 = "select user_name from user_accounts;";
    $res1 = mysqli_query($con, $qry1);
    while ($row = mysqli_fetch_array($res1)) {
        if (strcasecmp($row['user_name'], $read_user_name) == 0) {
            $user_found = TRUE;
            break;
        }
    }

    if ($user_found == TRUE) {
        $user_exist_message = "<span id='user_name_exists' style='display:inline;color:red'><br />User name already exists. Please choose the another one.</span>";
        mysqli_close($con);
    } else {
        // Store data and redirect to the verification page.
        if ($read_account_type == 1) {
            $msg_sub = " OLS - Registration verification code.";
            $msg_body = "<h3>Hi $read_user_name, Welcome to OLS Your verification code is : <span style='color:red'><i>$verification_code</i></span></h3>";
            //code to send verification code to email-ID.

            $mail = new PHPMailer;
            $mail->isSMTP();
            $mail->SMTPSecure = 'ssl';
            $mail->SMTPAuth = true;
            $mail->Host = 'smtp.gmail.com';
            $mail->Port = 465;
            $mail->Username = <Your_email_ID_as_string>;
            $mail->Password = <Your_email_password_as_string>;
            $mail->setFrom(<Your_email_ID_as_string>);
            $mail->addAddress($read_email_id);
            $mail->isHTML(TRUE); // To send the HTML formatted text.
            $mail->Subject = $msg_sub;
            $mail->Body = $msg_body;

            //send the message, check for errors
            if (!$mail->send()) {
                echo "<h1 style='color:red'>ERROR. Email sending failed. </h1> Details are : " . $mail->ErrorInfo;
                exit(0);
            }
            //code to send verification code to email-ID.
        }
        if ($read_account_type == 2) {
            //Resource persons needed to be verified by maintenance team
            $verification_code = 0;
        }

        $profile_pic_name = "";
        if ($read_sex == 0) {
            $profile_pic_name = "male.jpg";
        } else {
            $profile_pic_name = "female.jpg";
        }
        $qry2 = "INSERT INTO `user_accounts` (`user_id`, `user_name`, `password`, `stream`, `account_type`, `full_name`, `sex`, `email`, `registered_on`, `profile_pic_name`, `verified`, `verification_code`,`blocked`) VALUES (NULL, '$read_user_name', '$read_user_password_hash', '$read_stream', '$read_account_type', '$read_full_name', '$read_sex', '$read_email_id', '$account_created_date', '$profile_pic_name', '0', '$verification_code','0');";
        $res2 = mysqli_query($con, $qry2);
        if (!$res2) {
            echo "<h1  style='color:red'>Error in inserting user account details. Script is going to EXIT.<br> Details : " . mysqli_error($con) . "</h1>";
            exit(2);
        }
        mysqli_close($con);
        if ($read_account_type == 1) {
            $_SESSION['verification_required_user'] = $read_user_name;
            header("location:verification_page.php");
        } else {
            ?>

            <h1 style='color:green'>Thank you sir for signing-up. We will send a notification message to your email-ID as soon as your account is activated.</h1>
            <a href="index.php">OLS Home</a>
            <?php
            exit(1);
        }
    }
}
?>
<html>

    <head>
        <title>OLS - Registration </title>

        <script src="libraries/jquery-3.1.1.min.js"></script>
        <link href="libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
        <link href="libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
        <script src="libraries/bootstrap/js/bootstrap.js"></script>

        <script type="text/javascript">
            function validate_input() {
                var full_name = document.getElementById('full_name').value;
                var email_id = document.getElementById('email_id').value;
                var user_name = document.getElementById('user_name').value;
                var user_password = document.getElementById('user_password').value;
                var confirm_password = document.getElementById('confirm_password').value;
                var stream = document.getElementById('stream').value;
                var account_type = document.getElementById('account_type').value;

                var reg_exp_no_special_chars = /^[ ._0-9a-z]*$/i; // White spaces are allowed "Indicated at first place in [] brackets"
                var reg_exp_email = /^[_.@0-9a-z]*$/i; // dots and @ symbol are allowed.               
                var error_flag = false;
                if (full_name.search(reg_exp_no_special_chars) != 0) {
                    error_flag = true;
                    document.getElementById('full_name_error').style.display = "inline";
                }
                if (email_id.search(reg_exp_email) != 0) {
                    error_flag = true;
                    document.getElementById('email_id_error').style.display = "inline";
                }
                if (user_name.search(reg_exp_no_special_chars) != 0) {
                    error_flag = true;
                    document.getElementById('user_name_error').style.display = "inline";
                }
                if (user_password.search(reg_exp_email) != 0) {
                    error_flag = true;
                    document.getElementById('user_password_error').style.display = "inline";
                }
                if (stream == 0) {
                    error_flag = true;
                    document.getElementById('stream_error').style.display = "inline";
                }
                if (account_type == 0) {
                    error_flag = true;
                    document.getElementById('account_type_error').style.display = "inline";
                }
                if (user_password != confirm_password) {
                    error_flag = true;
                    document.getElementById('confirm_password_error').style.display = "inline";
                }
                if (error_flag == true) {
                    return false;
                    //Invalid input is given.
                } else {
                    return true;
                    // Valid input is given.
                }
            }

            function dismiss_error_message(span_id) {
                document.getElementById(span_id).style.display = "none";
            }

            //To dismiss user name related errors as it takes two parameters
            function dismiss_error_message_user_name(span_id1, span_id2) {
                document.getElementById(span_id1).style.display = "none";
                document.getElementById(span_id2).style.display = "none";
            }

        </script>
    </head>

    <body style="padding-top:30px; background-image:url(OLS_Images/login_registration.jpg); background-size:100%;background-attachment:fixed;">
        <div style="margin-top: 90px;">
            <div class="container">
                <form method="post" onsubmit="return validate_input();" style="max-width:500px;padding:19px 29px 29px;margin: 0 auto;background-color:#f2f2f2; border: 1px solid #080808; border-radius: 5px;box-shadow: 0 1px 70px rgb(0, 0, 0);font-family: Tahoma, Geneva, sans-serif;font-weight: lighter;">
                    <h2 style="color:#00A2D1;">Sign up.</h2>
                    <hr/>

                    <div class="form-group">
                        <label>  Full name <br/> </label>
                        <input type="text" id="full_name" name="full_name" maxlength="95" class="form-control" placeholder="Enter full name here" required="required" onclick="dismiss_error_message('full_name_error');" />
                        <span id="full_name_error" style="display:none;color:red">Invalid full name. Only underscore(_), numbers and alphabets are allowed.</span>
                    </div>

                    <div class="form-group">
                        <label>   Email id  <br/> </label>
                        <input type="email" id="email_id" name="email_id" maxlength="95" class="form-control" placeholder="Enter Email-ID here" required="required" onclick="dismiss_error_message('email_id_error');" />
                        <span id="email_id_error" style="display:none;color:red">Invalid Email-ID. Only underscore(_) dot(.) @ numbers[0-9] and alphabets are allowed.</span>
                    </div>

                    <div class="form-group">
                        <label>   User name <br/> </label>
                        <input type="text" id="user_name" name="user_name" maxlength="95" class="form-control" placeholder="Enter USER NAME here" required="required" onclick="dismiss_error_message_user_name('user_name_error', 'user_name_exists');" />
                        <span id="user_name_error" style="display:none;color:red">Invalid user name.  Only underscore(_), numbers and alphabets are allowed.</span>
                        <?php
                        if (isset($user_exist_message)) {
                            echo $user_exist_message;
                        }
                        ?>
                    </div>

                    <div class="form-group">
                        <label>   Password <br/> </label>
                        <input type="password" id="user_password" name="user_password" maxlength="95" class="form-control" placeholder="Enter password here" required="required" onclick="dismiss_error_message('user_password_error');" />
                        <span id="user_password_error" style="display:none;color:red">Invalid password. Only underscore(_) dot(.) @ numbers[0-9] and alphabets are allowed.</span>
                    </div>

                    <div class="form-group">
                        <label>   Confirm password <br/> </label>
                        <input type="password" id="confirm_password" name="confirm_password" maxlength="95" class="form-control" placeholder="Re-enter password here" required="required" onclick="dismiss_error_message('confirm_password_error');" />
                        <span id="confirm_password_error" style="display:none;color:red">Password DOES NOT match to above typed one.</span>
                    </div>

                    <div class="form-group">
                        <label>   Choose stream <br/></label>
                        <select id="stream" name="stream" class="form-control" onclick="dismiss_error_message('stream_error');">
                            <option value="0">Select Stream</option>
                            <option value="1">Computer science</option>
                            <option value="2">Information science</option>
                            <option value="3">Civil Engg</option>
                            <option value="4">Mechanical engg</option>
                            <option value="5">Electronics</option>
                            <option value="6">Other</option>
                        </select>
                        <span id="stream_error" style="display:none;color:red">Please select the stream</span>
                    </div>


                    <div class="form-group">
                        <label> Choose account type <br/></label>
                        <select id="account_type" name="account_type" class="form-control" onclick="dismiss_error_message('account_type_error');">
                            <option value="0">select account type</option>
                            <option value="1">Learner/student</option>
                            <option value="2">Resource person</option>
                        </select>
                        <span id="account_type_error" style="display:none;color:red">Please select the account type</span>
                    </div>

                    <div class="form-group">
                        <label> Sex &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  </label>
                        <input type="radio" name="sex" value="0" checked="checked" /> Male &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="radio" name="sex" value="1" /> Female &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </label>
                    </div>

                    <hr/>
                    <br />

                    <div class="form-group">
                        <button type="submit" class="btn btn-default" name="register_submit">
                            <span class="glyphicon glyphicon-log-in"></span> &nbsp; Create Account
                        </button>
                        <input type="reset" class="btn btn-default" style="float:right;" value="Reset" />
                    </div>

                </form>
            </div>
        </div>
    </body>

</html>
