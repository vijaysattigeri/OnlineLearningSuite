<?php
session_start();
include 'database_connect_parameters.inc';
if (isset($_SESSION['logged_in_maintain_user'])) {
    ?>
    <htmL>
        <head>
            <title>Account block</title>
            <!-- First INCLUDE JQuery library later include/link bootstrap-->
            <script src="libraries/jquery-3.1.1.min.js"></script>
            <script src="libraries/smooth_scroll/jquery.easing.min.js"></script>
            <script src="libraries/smooth_scroll/scrolling-nav.js"></script>
            <link href="libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
            <link href="libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
            <script src="libraries/bootstrap/js/bootstrap.js"></script>
            <link href="smooth_scroll/scrolling-nav.css" rel="stylesheet" />
            <script type="text/javascript">
                function confirm_block()
                {
                    if (confirm("Sure want to block ?"))
                    {
                        return true;
                    } else
                    {
                        return false;
                    }
                }
            </script>
        </head>

        <body style="padding-top:140px; background-image:url(OLS_Images/maintain_bg.jpg); background-size:100%;background-attachment:fixed;">
            <!--Style By Vijay-->

            <div id="top_nav_bar_vj">
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="container-fluid" style="background-color:#0080ff;font-variant-caps:all-petite-caps;">
                        <!--This gives enough padding for navbar elements-->
                        <div class="navbar-header" style="color:#ffffff;">
                            <button type="button" class="navbar-toggle" data-target="#resize_menu_vj_top" data-toggle="collapse">
                                <!-- To get THREE bars(Icon bars) when we resize the window to smaller size-->
                                <span class="glyphicon glyphicon-menu-hamburger"></span>
                                <span>Menu</span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse" id="resize_menu_vj_top">
                            <ul class="nav navbar-nav">
                                <li id="list_id_index"><a class="page-scroll" href="maintenance_team.php"><img src="OLS_Images/settings.jpg" width="50" height="50" style="border-radius:2px 18px" /><span style="color:#ffffff; font:initial; font-style:italic; font-size:xx-large;">&nbsp; OLS Maintenance home</span></a></li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">                                
                                <li id="list_id_logout"><a href="logout.php"><img src="OLS_Images/logout.jpg" width="40" height="40" style="border-radius:10px 10px" /><span style="font-size:large;color:#ffffff;">&nbsp; LOGOUT</span></a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>        

            <div class="container-fluid" style="padding:25px 25px 25px 25px; background-color:white;border-radius:20px 20px; box-shadow:0 1px 100px rgb(200, 71, 71);">
                <h1 style="text-align:center;color:red; ">Blocking users</h1>
                <br/>
                <form action="block_user_script.php" method="post" onsubmit="return confirm_block();">     
                    <table class="table table-striped">
                        <tr>
                            <th>User Name</th>
                            <th>Full Name</th>
                            <th>Stream</th>
                            <th>Account type</th>
                            <th>Email</th>
                            <th>Registered on</th>
                            <th>Sex</th>
                            <th>Check to block</th>
                        </tr>


                        <?php
                        $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
                        if (!$con) {
                            die('Could not connect to database: ' . mysql_error());
                            exit(14);
                        }
                        $empty_flag = TRUE;
                        $qry1 = "SELECT * FROM `user_accounts` where blocked='0';";
                        $res1 = mysqli_query($con, $qry1);
                        while ($row = mysqli_fetch_array($res1)) {
                            $empty_flag = FALSE;
                            $read_user_name = htmlentities($row['user_name'], ENT_QUOTES);
                            $read_full_name = htmlentities($row['full_name'], ENT_QUOTES);
                            $read_stream = $row['stream'];
                            $read_ac_tp = $row['account_type'];
                            $read_email = $row['email'];
                            $read_sx = $row['sex'];
                            $read_reg_on = $row['registered_on'];
                            $read_profile_pic_name = htmlentities($row['profile_pic_name'], ENT_QUOTES);

                            $registered_on = "<script type='text/javascript'> var dtjs = new Date('$read_reg_on'); document.write(dtjs.toDateString()); document.write(' at '+dtjs.toLocaleTimeString()); </script>"; // Converting date to MORE READABLE form by using javascript
                            $sex = "";
                            $account_type = "";
                            $stream = "";
                            switch ($read_stream) {
                                case 1: $stream = "Computer Science";
                                    break;
                                case 2: $stream = "Information Science";
                                    break;
                                case 3: $stream = "Civil Engineering";
                                    break;
                                case 4: $stream = "Mechanical Engineering";
                                    break;
                                case 5: $stream = "Electronics Engineering";
                                    break;
                                case 6: $stream = "Other";
                                    break;
                                default : $stream = "";
                                    break;
                            }
                            if ($read_sx == 0) {
                                $sex = "Male";
                            } else {
                                $sex = "Female";
                            }
                            if ($read_ac_tp == 1) {
                                $account_type = "Learner/student";
                            } else {
                                $account_type = "Resource person";
                            }
                            ?>
                            <tr>
                                <td><?php echo $read_user_name; ?></td>
                                <td><?php echo $read_full_name; ?></td>

                                <td><?php echo $stream; ?></td>

                                <td><?php echo $account_type; ?></td>

                                <td><?php echo $read_email; ?></td>

                                <td><?php echo $registered_on; ?></td>

                                <td><?php echo $sex; ?></td>

                                <td><input type="checkbox" name="account_ids[]" value="<?php echo $row['user_id']; ?>" /> Block</td>
                            <input type="hidden" name="user_names[]" value="<?php echo $row['user_name']; ?>" />
                            <input type="hidden" name="emails[]" value="<?php echo $row['email']; ?>" />

                            </tr>

                            <?php
                        }
                        if ($empty_flag == TRUE) {
                            echo "<div><h1 style='color:red'>No more accounts to be blocked</h1></div>";
                        }
                        mysqli_close($con);
                        ?>
                    </table>
                    <br/>
                    <input type="submit" name="submit_block" value="Submit" class="btn btn-danger" />
                    <input type="reset" value="Reset" class="btn-warning" style="float: right;" />                    
                </form>
            </div>
        </body>
    </htmL>
    <?php
} else {
    header("location:login.php");
}