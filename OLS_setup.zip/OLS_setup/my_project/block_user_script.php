<?php

session_start();
include 'database_connect_parameters.inc';
require 'PHPMailer/PHPMailerAutoload.php';
if (isset($_SESSION['logged_in_maintain_user'])) {

    $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
    if (!$con) {
        die('Could not connect to database: ' . mysql_error());
        exit(14);
    }

    if (isset($_REQUEST['account_ids']) && isset($_REQUEST['user_names']) && isset($_REQUEST['emails'])) {
        $account_ids = $_REQUEST['account_ids'];
        $user_name_array = $_REQUEST['user_names'];
        $email_array = $_REQUEST['emails'];


        $counter = 0;
        foreach ($account_ids as $ac_id) {
            $user_name = $user_name_array[$counter];
            $recipient_email = $email_array[$counter];
            $qry1 = "UPDATE `user_accounts` SET `blocked` = '1' WHERE user_id = '$ac_id';";
            $res1 = mysqli_query($con, $qry1);

            if ($res1) {
                $msg_sub = "<h2 style='color:green'> OLS - account block notification. </h2>";
                $msg_body = "<h3>Hi $user_name, sorry to inform you. Your account has been blocked due to your misbehaviors.</h3>";

                //code to send verification code to email-ID.

                $mail = new PHPMailer;
                $mail->isSMTP();
                $mail->SMTPSecure = 'ssl';
                $mail->SMTPAuth = true;
                $mail->Host = 'smtp.gmail.com';
                $mail->Port = 465;
                $mail->Username = <Your_email_ID_as_string>;
                $mail->Password = <Your_email_password_as_string>;
                $mail->setFrom(<Your_email_ID_as_string>);
                $mail->addAddress($recipient_email);
                $mail->isHTML(TRUE); // To send the HTML formatted text.
                $mail->Subject = $msg_sub;
                $mail->Body = $msg_body;

                //send the message, DON'T check for errors. Not necessary
                $mail->send();
                //code to send verification code to email-ID.
            } else {
                echo "<h1 style='color:red'>Updation to the table <i>user_accounts</i> failed. Account cannot be blocked please try again.</h1>";
                exit(1);
            }
            $counter++;
        }
    }
    mysqli_close($con);
    header("location:maintenance_team.php");
} else {
    header("location:login.php");
}