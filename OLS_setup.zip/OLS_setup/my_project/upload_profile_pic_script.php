<?php

session_start();
include 'database_connect_parameters.inc';

if (isset($_SESSION['logged_in_user_name'])) {

    if (isset($_REQUEST['profile_pic_upload'])) {
// Obtain Uploaded file details
        $size = $_FILES['image_file']['size'];
        $file_name = $_FILES['image_file']['name'];
        $category = $_FILES['image_file']['type'];
        $error = $_FILES['image_file']['error'];
        $err_no = $error;
        $type = pathinfo($file_name, PATHINFO_EXTENSION);  // To get file extension

        if ($file_name == "") {
            header("Location:upload_profile_pic.php");
            // if the file is not selected then script is REDIRECTED to the form page = upload_dialog.html 
        }

//Checking permissible file type
        $valid_type = array("jpeg", "jpg", "png", "bmp", "gif");
        $invalid_type_flag = 1;
        foreach ($valid_type as $tp) {
            if (strcasecmp($type, $tp) == 0) {
                $invalid_type_flag = 0;
            }
        }

//Uploaded file error.
        if ($err_no != 0) {

            switch ($err_no) {
                case 0: $error = "<span style='color:green'>NO error : UPLOAD_ERR_OK :  Status :  OK</span>";
                    break;
                case 1: $error = "<span style='color:red'>ERROR : UPLOAD_ERR_INI_SIZE: File size is more than maximum specified limit.</span>";
                    break;
                case 2: $error = "<span style='color:red'>ERROR : UPLOAD_ERR_FORM_SIZE : File size eceeding max. POST size of HTML form</span>";
                    break;
                case 3: $error = "<span style='color:red'>ERROR : UPLOAD_ERR_PARTIAL : Partial file upload error due to network failure</span>";
                    break;
                case 4: $error = "<span style='color:red'>ERROR : UPLOAD_ERR_NO_FILE : No file is selected</span>";
                    break;
                default : $error = "UNSPECIFIED ERROR : Some error occured..";
                    break;
            }
        }

//File size check
        $max_size = (50 * 1024 * 1024);
        $size_invalid = 0;
        if ($size > $max_size || $size == 0) {
            $size_invalid = 1;
        }

        if ($err_no != 0 || $invalid_type_flag == 1 || $size_invalid == 1) {
            $err1 = "";
            $err2 = "";
            $err3 = "";
            if ($err_no != 0) {
                $errr1 = $error;
            }
            if ($invalid_type_flag == 1) {
                $err2 = "Illegeal file. Only images are allowed";
            }
            if ($size_invalid == 1) {
                $err3 = "File is too large or too small. Maximum : Minimum file size is = 50MB : 1B ";
            }
            echo "<html><head><title>INPUT ERROR</title></head><body><h2 style='color:red'>ERROR LIST :-----</br> </h2><ul style='color:red'><li>$err1</li><li>$err2</li><li>$err3</li></ul>";
            echo"<a href='upload_dialog.php'>Back to upload page</a><br/><br/><a href='index.php'>OLS Home</a></body></html>";
        } else {  // If all parameters are valid.
// Connection
            $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
            if (!$con) {
                die('Could not connect: ' . mysql_error());
                exit(14);
            }

// To generate file names to be stored
            $u_name = $_SESSION['logged_in_user_name'];
            $pic_store_name = "$u_name.$type";

            $qry1 = "UPDATE `user_accounts` SET `profile_pic_name` = '$pic_store_name' WHERE `user_accounts`.`user_name` = '$u_name'";
            $res1 = mysqli_query($con, $qry1);

            $qry2 = "UPDATE `forum_questions` SET `profile_pic_name` = '$pic_store_name' WHERE `forum_questions`.`posted_by` = '$u_name'; ";
            $res2 = mysqli_query($con, $qry2);

            $qry3 = "UPDATE `forum_answers` SET `profile_pic_name` = '$pic_store_name' WHERE `forum_answers`.`posted_by` = '$u_name';";
            $res3 = mysqli_query($con, $qry3);

            move_uploaded_file($_FILES['image_file']['tmp_name'], "profile_pics/$pic_store_name"); // first argument for above program must be temporary file name else copy will not happen

            if ($res1 && $res2 && $res3) {
                //File uploading successful so redirect to RESOURCE HOUSE home
                mysqli_close($con);
                header("location:user_profile.php");
            } else {
                echo'<h3 style="color:red">Insertion failed. Issue : <i>' . mysqli_error($con) . '</i></h3><br/>';
            }
            mysqli_close($con);
        }
    } else {
        header("location:index.php");
    }
} else {
    header("location:login.php");
}
?>