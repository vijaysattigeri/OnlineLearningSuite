	
	******* Administrator account / Maintenance team login details *******

				User Name : ols_admin
				Password  : 9590779164


	******* Sample user account details *******
			
		1) Learner/student account
			User Name : vj
			Password  : 1234
		
		2) Resource person account
			User Name : vijay
			Password  : 1234



