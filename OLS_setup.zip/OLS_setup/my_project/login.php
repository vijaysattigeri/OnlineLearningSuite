<?php
session_start();
include 'database_connect_parameters.inc';
if (isset($_SESSION['verification_required_user'])) {
    header("location:verification_page.php");
}
if (isset($_SESSION['logged_in_user_name'])) {
    header("location:index.php");
}
if (isset($_SESSION['logged_in_maintain_user'])) {
    header("location:maintenance_team.php");
}

$login_error_msg = "";
$login_status_flag = FALSE;
if (isset($_REQUEST['login_submit'])) {
    $form_user_name = trim($_REQUEST['form_user_name']);
    $form_user_password = $_REQUEST['form_user_password'];
    $password_hash = md5($form_user_password);

    //For maintenance_team login
    $maintenance_user_name = "OLS_admin";
    $maintenance_user_password = "9590779164";

    if ((strcasecmp($maintenance_user_name, $form_user_name) == 0) && (strcasecmp($maintenance_user_password, $form_user_password) == 0)) {
        $_SESSION['logged_in_maintain_user'] = $maintenance_user_name;
        header("location:maintenance_team.php");
    }

    $con = mysqli_connect($database_host, $database_user, $database_password, $database_name);
    if (!$con) {
        die('Could not connect to database : ' . mysql_error());
    }

    $qry1 = "select * from user_accounts";
    $res1 = mysqli_query($con, $qry1);
    while ($row = mysqli_fetch_array($res1)) {
        if ((strcasecmp($row['user_name'], $form_user_name) == 0) && (strcasecmp($password_hash, $row['password']) == 0)) {
            $login_status_flag = TRUE;
            if ($row['verified'] == 0 && $row['account_type'] == 2) {
                ?>
                <h1 style='color:green'>Your account is under processing. We will send a notification message to your email-ID as soon as your account is activated.</h1>
                <a href="index.php">OLS Home</a>            
                <?php
                exit(1);
            } elseif ($row['verified'] == 0) {
                $_SESSION['verification_required_user'] = $row['user_name'];
                header("location:verification_page.php");
            } elseif ($row['blocked'] != 0) {
                echo "<h1 style='color:red'>Sorry \"" . $row['user_name'] . "\" you're <i>BLOCKED.</i></h1><a href='index.php'>OLS Home</a>";
                exit(1);
            } else {
                $_SESSION['logged_in_user_name'] = $row['user_name'];
                $_SESSION['logged_in_user_id'] = $row['user_id'];
                $_SESSION['logged_in_user_stream'] = $row['stream'];
                $_SESSION['logged_in_user_account_type'] = $row['account_type'];
                $_SESSION['logged_in_user_profile_pic_name'] = $row['profile_pic_name'];

                header("location:index.php");
            }
        }
    }
    if ($login_status_flag == FALSE) {
        $login_error_msg = "<h4 id='login_failure' style='color:red'>Login failure. Please input valid details.</h4>";
    }
}
?>
<htmL>
    <head>
        <title>
            OLS login page
        </title>
        <meta name="viewport" content="width=device-width, initial-scale=1">    
        <script src="libraries/jquery-3.1.1.min.js"></script>    
        <link href="libraries/bootstrap/css/bootstrap-theme.css" rel="stylesheet" />
        <link href="libraries/bootstrap/css/bootstrap.css" rel="stylesheet" />
        <script src="libraries/bootstrap/js/bootstrap.js"></script>
        <script type="text/javascript">
            function clear_log_error_msg() {
                document.getElementById('login_failure').style.display = "none";
            }
        </script>
    </head>
    <body style="padding-top:80px; background-image:url(OLS_Images/login_registration.jpg); background-size:100%;background-attachment:fixed;">  
        <div style="margin-top: 90px;">
            <div class="container">
                <form method="POST" style="max-width:500px;padding:19px 29px 29px;margin: 0 auto;background-color:#f2f2f2; border: 1px solid #080808; border-radius: 5px;box-shadow: 0 1px 70px rgb(0, 0, 0);font-family: Tahoma, Geneva, sans-serif;font-weight: lighter;">
                    <h2 style="color:#00A2D1;">Sign In.</h2>
                    <hr/>
                    <?php
                    if (isset($login_error_msg)) {
                        echo $login_error_msg;
                    }
                    ?>
                    <div class="form-group">
                        <label> User name <br/> </label>                
                        <input type="text" class="form-control" placeholder="Enter user name here" name="form_user_name" required="required" onclick="clear_log_error_msg();" />
                    </div>   
                    <div class="form-group">
                        <label> Password <br/> </label>
                        <input type="password" class="form-control" placeholder="Enter password here" name="form_user_password" required="required" onclick="clear_log_error_msg();" />
                    </div>
                    <hr/>
                    <br/>
                    <div class="form-group">
                        <button type="submit" class="btn btn-default" name="login_submit">
                            <span class="glyphicon glyphicon-log-in"></span> &nbsp; Sign In
                        </button>             
                        <a href="register.php" class="btn btn-default" style="float:right;">Create an account</a>
                    </div>   
                    <br/>
                </form>
            </div>        
        </div> 
    </body>
</htmL>