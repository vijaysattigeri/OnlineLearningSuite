-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2017 at 05:57 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `exam_question_paper`
--

CREATE TABLE `exam_question_paper` (
  `q_id` int(10) UNSIGNED NOT NULL,
  `question` text NOT NULL,
  `option1` text NOT NULL,
  `option2` text NOT NULL,
  `option3` text NOT NULL,
  `option4` text NOT NULL,
  `answer` tinyint(4) NOT NULL,
  `stream` tinyint(3) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exam_student`
--

CREATE TABLE `exam_student` (
  `table_id` int(10) UNSIGNED NOT NULL,
  `q_id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `stream` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `forum_answers`
--

CREATE TABLE `forum_answers` (
  `answer_id` int(10) UNSIGNED NOT NULL,
  `q_id_foreign` int(10) UNSIGNED NOT NULL,
  `answer` text NOT NULL,
  `posted_date` datetime NOT NULL,
  `posted_by` varchar(50) NOT NULL,
  `profile_pic_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `forum_questions`
--

CREATE TABLE `forum_questions` (
  `question_id` int(10) UNSIGNED NOT NULL,
  `question` text NOT NULL,
  `posted_date` datetime NOT NULL,
  `posted_by` varchar(50) NOT NULL,
  `profile_pic_name` text NOT NULL,
  `stream` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `previous_question_set`
--

CREATE TABLE `previous_question_set` (
  `file_id` int(10) UNSIGNED NOT NULL,
  `file_name` varchar(60) NOT NULL,
  `create_date` datetime NOT NULL,
  `stream` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `resource_house`
--

CREATE TABLE `resource_house` (
  `id` int(10) UNSIGNED NOT NULL,
  `file_name` varchar(100) NOT NULL,
  `stored_file_name` varchar(100) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `file_path` text NOT NULL,
  `upload_date` datetime NOT NULL,
  `download_count` int(11) NOT NULL,
  `file_size` float NOT NULL,
  `file_type` varchar(16) NOT NULL,
  `stream` tinyint(3) UNSIGNED NOT NULL,
  `description` text NOT NULL,
  `category` varchar(50) NOT NULL,
  `valid` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tutorial_attachments`
--

CREATE TABLE `tutorial_attachments` (
  `tutorial_id_foreign` int(11) NOT NULL,
  `file_name` text NOT NULL,
  `stored_file_name` text NOT NULL,
  `attachment_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tutorial_section`
--

CREATE TABLE `tutorial_section` (
  `tutorial_id` int(11) NOT NULL,
  `tutorial_title` varchar(100) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `posted_date` datetime NOT NULL,
  `video_path` text NOT NULL,
  `type` varchar(20) NOT NULL,
  `image_path` text NOT NULL,
  `explanation` longtext NOT NULL,
  `stream` tinyint(3) UNSIGNED NOT NULL,
  `number_of_attachments` int(11) NOT NULL,
  `tut_attach_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_accounts`
--

CREATE TABLE `user_accounts` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `stream` tinyint(4) NOT NULL,
  `account_type` tinyint(1) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `sex` tinyint(1) NOT NULL,
  `email` varchar(100) NOT NULL,
  `registered_on` datetime NOT NULL,
  `profile_pic_name` text NOT NULL,
  `verified` tinyint(1) NOT NULL,
  `verification_code` int(7) UNSIGNED NOT NULL,
  `blocked` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `exam_question_paper`
--
ALTER TABLE `exam_question_paper`
  ADD PRIMARY KEY (`q_id`);

--
-- Indexes for table `exam_student`
--
ALTER TABLE `exam_student`
  ADD PRIMARY KEY (`table_id`),
  ADD KEY `q_id` (`q_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `forum_answers`
--
ALTER TABLE `forum_answers`
  ADD PRIMARY KEY (`answer_id`),
  ADD KEY `q_id_foreign` (`q_id_foreign`);

--
-- Indexes for table `forum_questions`
--
ALTER TABLE `forum_questions`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `previous_question_set`
--
ALTER TABLE `previous_question_set`
  ADD PRIMARY KEY (`file_id`);

--
-- Indexes for table `resource_house`
--
ALTER TABLE `resource_house`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tutorial_attachments`
--
ALTER TABLE `tutorial_attachments`
  ADD PRIMARY KEY (`attachment_id`),
  ADD KEY `tutorial_id_foreign` (`tutorial_id_foreign`);

--
-- Indexes for table `tutorial_section`
--
ALTER TABLE `tutorial_section`
  ADD PRIMARY KEY (`tutorial_id`);

--
-- Indexes for table `user_accounts`
--
ALTER TABLE `user_accounts`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_name` (`user_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `exam_question_paper`
--
ALTER TABLE `exam_question_paper`
  MODIFY `q_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `exam_student`
--
ALTER TABLE `exam_student`
  MODIFY `table_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `forum_answers`
--
ALTER TABLE `forum_answers`
  MODIFY `answer_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `forum_questions`
--
ALTER TABLE `forum_questions`
  MODIFY `question_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `previous_question_set`
--
ALTER TABLE `previous_question_set`
  MODIFY `file_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `resource_house`
--
ALTER TABLE `resource_house`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tutorial_attachments`
--
ALTER TABLE `tutorial_attachments`
  MODIFY `attachment_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tutorial_section`
--
ALTER TABLE `tutorial_section`
  MODIFY `tutorial_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_accounts`
--
ALTER TABLE `user_accounts`
  MODIFY `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `exam_student`
--
ALTER TABLE `exam_student`
  ADD CONSTRAINT `exam_student_ibfk_1` FOREIGN KEY (`q_id`) REFERENCES `exam_question_paper` (`q_id`),
  ADD CONSTRAINT `exam_student_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `user_accounts` (`user_id`);

--
-- Constraints for table `forum_answers`
--
ALTER TABLE `forum_answers`
  ADD CONSTRAINT `forum_answers_ibfk_1` FOREIGN KEY (`q_id_foreign`) REFERENCES `forum_questions` (`question_id`);

--
-- Constraints for table `tutorial_attachments`
--
ALTER TABLE `tutorial_attachments`
  ADD CONSTRAINT `tutorial_attachments_ibfk_1` FOREIGN KEY (`tutorial_id_foreign`) REFERENCES `tutorial_section` (`tutorial_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
